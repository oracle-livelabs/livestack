#!/usr/bin/env bash
# Verify the static Resource Manager/native Select AI contract. The HigherEd
# donor retains a local Compose demo, so this script deliberately inspects the
# generated payload rather than the unshipped local-only source files.
set -Eeuo pipefail

SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PAYLOAD_PATH="${SOURCE_ROOT}/payload/highered-application.zip"
TEMP_APPLICATION_ROOT=""

fail() {
  printf 'FAIL: %s\n' "$*" >&2
  exit 1
}

cleanup() {
  [[ -z "${TEMP_APPLICATION_ROOT}" ]] || rm -rf -- "${TEMP_APPLICATION_ROOT}"
}
trap cleanup EXIT

command -v unzip >/dev/null 2>&1 || fail 'unzip is required to inspect the application payload.'
[[ -f "${PAYLOAD_PATH}" ]] || fail "Missing payload: ${PAYLOAD_PATH}"
TEMP_APPLICATION_ROOT="$(mktemp -d)"
unzip -q "${PAYLOAD_PATH}" -d "${TEMP_APPLICATION_ROOT}"

require_pattern() {
  local pattern="$1"
  local path="$2"
  grep -Eq "${pattern}" "${SOURCE_ROOT}/${path}" ||
    fail "${path} is missing required contract pattern: ${pattern}"
}

require_application_pattern() {
  local pattern="$1"
  local path="$2"
  grep -Eq "${pattern}" "${TEMP_APPLICATION_ROOT}/${path}" ||
    fail "payload/${path} is missing required contract pattern: ${pattern}"
}

forbidden_runtime_pattern='olla''ma|llama3[.]2|11434'
if grep -ERin "${forbidden_runtime_pattern}" "${TEMP_APPLICATION_ROOT}" >/dev/null; then
  grep -ERin "${forbidden_runtime_pattern}" "${TEMP_APPLICATION_ROOT}" >&2 || true
  fail 'Packaged application still contains a local-model runtime reference.'
fi

for local_only in \
  compose.yml \
  scripts/pull_ollama.sh \
  backend/lib/ollamaAssistant.js \
  db/schema/00_setup.sql \
  .env.example; do
  [[ ! -e "${TEMP_APPLICATION_ROOT}/${local_only}" ]] ||
    fail "Packaged application contains local-only source: ${local_only}"
done

if grep -ERn --include='*.tf' --include='*.yaml' --include='*.yml' \
  'BEGIN (RSA )?PRIVATE KEY|private_key(_b64)?[[:space:]]*=' \
  "${SOURCE_ROOT}" >/dev/null; then
  fail 'Terraform or metadata contains OCI private-key material or an input path for it.'
fi

require_pattern 'variable "tenancy_ocid"' variables.tf
require_pattern 'variable "current_user_ocid"' variables.tf
require_pattern 'variable "identity_domain_ocid"' variables.tf
require_pattern 'variable "bootstrap_generation"' variables.tf
require_pattern 'version[[:space:]]*=[[:space:]]*"=[[:space:]]*8[.]25[.]0"' versions.tf
require_pattern 'version[[:space:]]*=[[:space:]]*"=[[:space:]]*3[.]9[.]0"' versions.tf
require_pattern 'payload/highered-application[.]zip' main.tf
require_pattern 'HIGHERED_SELECTAI_V1' main.tf
require_pattern 'STUDENT_SIGNAL_TEAM,CAMPUS_SERVICE_TEAM,STUDENT_SUCCESS_TEAM' main.tf
require_pattern 'filesha256[(]local[.]application_payload_path[)]' main.tf
require_pattern 'source[[:space:]]*=[[:space:]]*local[.]application_payload_path' object-storage.tf
require_pattern 'for_each[[:space:]]*=[[:space:]]*toset[(]\[local[.]application_payload_sha256\]\)' object-storage.tf
require_pattern 'object[[:space:]]*=[[:space:]]*"application/payloads/\$\{each[.]key\}[.]zip"' object-storage.tf
require_pattern 'base64gzip[(]local[.]application_cloud_init[)]' compute-app.tf
require_pattern 'application_instance_metadata_budget_bytes[[:space:]]*=[[:space:]]*30000' compute-app.tf
require_pattern 'data "oci_identity_domain" "selected"' select-ai-key.tf
require_pattern 'resource "oci_identity_domains_my_api_key" "select_ai"' select-ai-key.tf
require_pattern 'total_results[[:space:]]*<[[:space:]]*3' select-ai-key.tf
require_pattern 'rm -f "\$\{API_PRIVATE_KEY_FILE\}" "\$\{API_PUBLIC_KEY_FILE\}"' scripts/bootstrap_app_vm.sh
require_pattern 'bootstrap-highered-adb[.]sh' scripts/bootstrap_app_vm.sh
require_pattern 'NATIVE_SELECT_AI_ENABLED=true' scripts/bootstrap_app_vm.sh
require_pattern 'selectai_api_key_prerequisites' scripts/bootstrap_app_vm.sh

bootstrap_app_vm_path="${SOURCE_ROOT}/scripts/bootstrap_app_vm.sh"
key_exchange_line="$(grep -n '^generate_and_publish_api_key$' "${bootstrap_app_vm_path}" | cut -d: -f1)"
heavy_runtime_install_line="$(grep -n '^dnf -y install container-tools' "${bootstrap_app_vm_path}" | cut -d: -f1)"
[[ "${key_exchange_line}" =~ ^[0-9]+$ && "${heavy_runtime_install_line}" =~ ^[0-9]+$ &&
  "${key_exchange_line}" -lt "${heavy_runtime_install_line}" ]] ||
  fail 'The Select AI public-key callback must be published before heavyweight runtime installation.'

require_application_pattern 'HIGHERED_NATIVE_AI_SETUP_READY' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_NATIVE_AI_ACCEPTANCE_OK' deployment/bootstrap-highered-adb.sh
require_application_pattern 'wrapped_uri_count' deployment/bootstrap-highered-adb.sh
require_application_pattern 'wrapped_help_count' deployment/bootstrap-highered-adb.sh
require_application_pattern 'DBCC CREATE HIGHERED_GENAI_KEY_V1' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_SELECTAI_V1' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_READONLY_SQL_TOOL' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_NATIVE_AI_PKG' deployment/bootstrap-highered-adb.sh
require_application_pattern 'adb_dns_readiness' deployment/bootstrap-highered-adb.sh
require_application_pattern 'ORA-17868: Unknown host specified' deployment/bootstrap-highered-adb.sh
require_application_pattern "'object_list_mode' VALUE 'all'" deployment/bootstrap-highered-adb.sh
require_application_pattern "'enforce_object_list' VALUE 'true'" deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_RETENTION_PRESSURE_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_ADVANCEMENT_CAPACITY_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_RESOURCE_IMPACT_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_SIGNAL_ATTRIBUTION_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_SIGNAL_CHANNEL_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_SERVICE_CAPACITY_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_URGENT_AID_SIGNAL_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_SERVICE_ACCESS_V' deployment/bootstrap-highered-adb.sh
require_application_pattern 'DBMS_CLOUD_AI[.]GENERATE' deployment/bootstrap-highered-adb.sh
require_application_pattern 'DBMS_CLOUD_AI_AGENT[.]RUN_TOOL' deployment/bootstrap-highered-adb.sh
require_application_pattern 'DBMS_CLOUD_AI_AGENT[.]DESCRIBE_TEAM' deployment/bootstrap-highered-adb.sh
require_application_pattern 'STUDENT_SIGNAL_TEAM' deployment/bootstrap-highered-adb.sh
require_application_pattern 'CAMPUS_SERVICE_TEAM' deployment/bootstrap-highered-adb.sh
require_application_pattern 'STUDENT_SUCCESS_TEAM' deployment/bootstrap-highered-adb.sh
require_application_pattern 'GRANT EXECUTE ON DBMS_CLOUD TO APP_USER' deployment/bootstrap-highered-adb.sh
require_application_pattern 'GRANT EXECUTE ON DBMS_CLOUD_AI TO APP_USER' deployment/bootstrap-highered-adb.sh
require_application_pattern 'GRANT EXECUTE ON DBMS_CLOUD_AI_AGENT TO APP_USER' deployment/bootstrap-highered-adb.sh
require_application_pattern 'rebuild_spatial_locations' deployment/bootstrap-highered-adb.sh
require_application_pattern 'seed_vector_artifacts[.]sql' deployment/bootstrap-highered-adb.sh
require_application_pattern 'HIGHERED_VECTOR_ARTIFACTS_READY' db/data/seed_vector_artifacts.sql
require_application_pattern 'AND location IS NOT NULL' db/data/seed_fulfillment_zones.sql
require_application_pattern 'withActorConnection' backend/config/database.js
require_application_pattern 'nativeSelectAi' backend/routes/selectai.js
require_application_pattern 'nativeSelectAi' backend/routes/agents.js
require_application_pattern 'native[.]checkReadiness' backend/server.js
require_application_pattern 'HIGHERED_NATIVE_AI_PKG[.]GENERATE_TEXT' backend/lib/nativeSelectAi.js
require_application_pattern 'HIGHERED_RETENTION_PRESSURE_V' backend/lib/nativeSelectAi.js
require_application_pattern 'semanticViewForQuestion' backend/lib/nativeSelectAi.js

if grep -Eq 'resource[[:space:]]+"oci_identity_api_key"' "${SOURCE_ROOT}"/*.tf; then
  fail 'The legacy IAM /20160918 API-key resource must not be shipped.'
fi
if grep -ERq '^[[:space:]]*(data|resource)[[:space:]]+"archive_file"' "${SOURCE_ROOT}"/*.tf; then
  fail 'Terraform must consume the prebuilt payload, not create an archive during a job.'
fi
if grep -Eq 'hashicorp/archive' "${SOURCE_ROOT}/versions.tf"; then
  fail 'The unused archive provider must not be shipped.'
fi
if grep -Eq 'base64encode[[:space:]]*[(][[:space:]]*templatefile[[:space:]]*[(]' "${SOURCE_ROOT}/compute-app.tf"; then
  fail 'Cloud-init must be gzip-compressed before Base64 encoding.'
fi

bash -n \
  "${SOURCE_ROOT}/scripts/bootstrap_app_vm.sh" \
  "${SOURCE_ROOT}/scripts/publish_selectai_api_key_activation.sh" \
  "${SOURCE_ROOT}/scripts/wait_for_selectai_api_key_callback.sh" \
  "${SOURCE_ROOT}/scripts/wait_for_bootstrap_callback.sh" \
  "${TEMP_APPLICATION_ROOT}/deployment/bootstrap-highered-adb.sh"

python3 "${SOURCE_ROOT}/verification/check-resource-manager-package.py" --source-root "${SOURCE_ROOT}"
python3 "${SOURCE_ROOT}/verification/check-compute-metadata-budget.py"

if command -v terraform >/dev/null 2>&1; then
  terraform -chdir="${SOURCE_ROOT}" fmt -check -recursive >/dev/null
fi

printf 'PASS: HigherEd Resource Manager and native Select AI contract is intact.\n'
