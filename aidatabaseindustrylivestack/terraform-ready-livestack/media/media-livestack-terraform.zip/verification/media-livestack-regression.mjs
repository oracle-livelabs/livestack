#!/usr/bin/env node
/*
 * Safe operator-run regression for a deployed Media LiveStack.
 *
 * The default suite only reads health, metadata, and seeded demo data. Adding
 * --include-ai sends one read-only Ask Data request. Adding
 * --include-agent-chat sends one advisory Agent Console request, which can add
 * a proposed audit entry. Neither option imports, restores, or changes the
 * Media dataset.
 *
 * Usage:
 *   node media-livestack-regression.mjs --base-url http://host:8505
 *   node media-livestack-regression.mjs --base-url http://host:8505 --include-ai
 *   node media-livestack-regression.mjs --base-url http://host:8505 --include-agent-chat
 */

import assert from 'node:assert/strict';
import process from 'node:process';

function argument(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  return index === -1 ? fallback : process.argv[index + 1] || fallback;
}

const rawBaseUrl = argument('--base-url');
if (!rawBaseUrl) {
  console.error('Usage: node media-livestack-regression.mjs --base-url http://host:8505 [--include-ai] [--include-agent-chat]');
  process.exit(2);
}

const baseUrl = rawBaseUrl.replace(/\/+$/, '');
const timeoutMs = Number(argument('--timeout-ms', '120000'));
const agentTimeoutMs = Number(argument('--agent-timeout-ms', '300000'));
const runAi = process.argv.includes('--include-ai') || process.argv.includes('--include-agent-chat');
const runAgentChat = process.argv.includes('--include-agent-chat');
const results = [];
const demoUser = 'admin_jess';

function value(object, ...keys) {
  return keys.map((key) => object?.[key]).find((candidate) => candidate !== undefined && candidate !== null);
}

function nonEmptyArray(payload, label) {
  assert.ok(Array.isArray(payload), `${label} must be an array`);
  assert.ok(payload.length > 0, `${label} must not be empty`);
  return payload;
}

async function request(label, path, {
  method = 'GET', body, timeout = timeoutMs, headers = {}, expectedStatus = 200,
} = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method,
      headers: {
        accept: 'application/json',
        'x-demo-user': demoUser,
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`${label} returned non-JSON content: ${text.slice(0, 240)}`);
    }
    assert.equal(response.status, expectedStatus, `${label} returned HTTP ${response.status}: ${JSON.stringify(payload).slice(0, 500)}`);
    return { payload, response };
  } finally {
    clearTimeout(timer);
  }
}

async function requestText(label, path, { timeout = timeoutMs } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(new URL(path, `${baseUrl}/`), {
      headers: { accept: 'text/html,application/javascript,text/css,*/*' },
      signal: controller.signal,
    });
    const text = await response.text();
    assert.equal(
      response.status,
      200,
      `${label} returned HTTP ${response.status}: ${text.slice(0, 240)}`,
    );
    return { response, text };
  } finally {
    clearTimeout(timer);
  }
}

async function test(label, callback) {
  const started = Date.now();
  try {
    await callback();
    results.push({ label, status: 'PASS', elapsedMs: Date.now() - started });
    console.log(`PASS  ${label}`);
  } catch (error) {
    results.push({ label, status: 'FAIL', elapsedMs: Date.now() - started, error: error.message });
    console.error(`FAIL  ${label}: ${error.message}`);
  }
}

async function validateReadOnlyDemoPersona() {
  const { payload: users } = await request('demo users', '/api/users');
  const user = nonEmptyArray(users, 'demo users')
    .find((candidate) => value(candidate, 'USERNAME', 'username') === demoUser);
  assert.ok(user, `demo persona ${demoUser} is unavailable`);
  assert.equal(String(value(user, 'ROLE', 'role')).toLowerCase(), 'admin');
}

async function main() {
  await test('frontend HTML and built assets are browser-loadable', async () => {
    const { response, text: html } = await requestText('frontend HTML', '/');
    assert.match(html, /<div id="root"><\/div>/, 'frontend HTML has no React root');

    const csp = response.headers.get('content-security-policy') || '';
    if (new URL(baseUrl).protocol === 'http:') {
      assert.ok(
        !/upgrade-insecure-requests/i.test(csp),
        'HTTP frontend CSP upgrades its assets to unsupported HTTPS',
      );
    }

    const scriptPath = html.match(/src="([^"?]*\/assets\/[^"?]+[.]js)"/)?.[1];
    const stylesheetPath = html.match(/href="([^"?]*\/assets\/[^"?]+[.]css)"/)?.[1];
    assert.ok(scriptPath, 'frontend HTML has no built JavaScript asset');
    assert.ok(stylesheetPath, 'frontend HTML has no built stylesheet asset');
    await requestText('frontend JavaScript asset', scriptPath);
    await requestText('frontend stylesheet asset', stylesheetPath);
    await requestText('Oracle JET bootstrap asset', '/jet/bootstrap.js');
  });

  await test('connection: API health queries ADB', async () => {
    const { payload } = await request('API health', '/api/health');
    assert.equal(payload.status, 'healthy');
    assert.equal(String(value(payload.database, 'STATUS', 'status')).toLowerCase(), 'connected');
  });

  await test('governed admin persona is available', validateReadOnlyDemoPersona);

  await test('Media network graph page endpoints', async () => {
    const { payload: influencers } = await request(
      'Media graph influencers',
      '/api/graph/influencers?limit=1',
    );
    const influencer = nonEmptyArray(influencers, 'Media graph influencers')[0];
    const influencerId = value(influencer, 'INFLUENCER_ID', 'influencer_id');
    assert.ok(influencerId, 'Media graph influencer has no identifier');
    const { payload: network } = await request(
      'Media graph network',
      `/api/graph/network/${encodeURIComponent(influencerId)}?depth=1`,
    );
    assert.equal(typeof network.center, 'object', 'Media graph network has no center');
    nonEmptyArray(network.nodes, 'Media graph nodes');
    assert.ok(Array.isArray(network.edges), 'Media graph edges must be an array');
  });

  const simpleGetTests = [
    ['seeded Media demo status', '/api/demo/status', (body) => assert.equal(typeof body, 'object')],
    ['dashboard summary', '/api/dashboard/summary', (body) => assert.equal(typeof body, 'object')],
    ['Media capacity KPIs', '/api/fulfillment/kpis', (body) => assert.equal(typeof body, 'object')],
    ['Media OML summary', '/api/ml/summary', (body) => assert.equal(typeof body, 'object')],
    ['Select AI profile metadata', '/api/selectai/profiles', (body) => {
      const profiles = nonEmptyArray(body.profiles, 'Select AI profiles');
      assert.ok(profiles.some((profile) => value(profile, 'name', 'NAME') === 'MEDIA_SELECTAI_V1'));
    }],
    ['Select AI curated schema', '/api/selectai/schema-objects', (body) => nonEmptyArray(body.objects, 'Select AI schema objects')],
    ['Select AI readiness', '/api/selectai/health', (body) => assert.equal(body.status, 'healthy')],
    ['native agent profiles', '/api/agents/profiles', (body) => assert.equal(typeof body, 'object')],
    ['native agent teams', '/api/agents/teams', (body) => {
      const teams = nonEmptyArray(body, 'native agent teams').map((team) => value(team, 'TEAM_NAME', 'team_name', 'name'));
      for (const team of ['MEDIA_SIGNAL_TEAM', 'MEDIA_DISTRIBUTION_TEAM', 'MEDIA_REVENUE_TEAM']) {
        assert.ok(teams.includes(team), `native agent team ${team} is missing`);
      }
    }],
    ['agent audit history', '/api/agents/actions?limit=3', (body) => assert.ok(Array.isArray(body), 'agent audit history must be an array')],
  ];

  for (const [label, path, assertion] of simpleGetTests) {
    await test(label, async () => {
      const { payload } = await request(label, path);
      assertion(payload);
    });
  }

  if (runAi) {
    await test('governed Ask Data SQL', async () => {
      const { payload } = await request('governed Ask Data SQL', '/api/selectai/runsql', {
        method: 'POST',
        body: { question: 'Show content revenue by content category.' },
        timeout: agentTimeoutMs,
      });
      assert.equal(typeof payload.sql, 'string', 'Ask Data did not return generated SQL');
      assert.ok(Array.isArray(payload.rows), 'Ask Data did not return a row array');
      assert.equal(payload.readOnly, true, 'Ask Data did not preserve the read-only boundary');
    });
  } else {
    results.push({ label: 'governed Ask Data SQL', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  governed Ask Data SQL (use --include-ai to run one live Select AI request)');
  }

  if (runAgentChat) {
    await test('governed Agent Console advisory', async () => {
      const { payload } = await request('governed Agent Console advisory', '/api/agents/chat', {
        method: 'POST',
        body: {
          team: 'MEDIA_REVENUE_TEAM',
          question: 'Show content revenue by content category.',
        },
        timeout: agentTimeoutMs,
      });
      assert.equal(typeof payload.response, 'string', 'Agent Console returned no advisory response');
      assert.equal(payload.team, 'MEDIA_REVENUE_TEAM', 'Agent Console did not use MEDIA_REVENUE_TEAM');
      assert.equal(payload.readOnly, true, 'Agent Console did not preserve the read-only boundary');
      assert.equal(payload.advisory, true, 'Agent Console did not preserve the advisory boundary');
    });
  } else {
    results.push({ label: 'governed Agent Console advisory', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  governed Agent Console advisory (use --include-agent-chat; it can add one proposed audit entry)');
  }

  const passed = results.filter((result) => result.status === 'PASS').length;
  const failed = results.filter((result) => result.status === 'FAIL');
  const skipped = results.filter((result) => result.status === 'SKIP').length;
  console.log(`\nMedia regression summary: ${passed} passed, ${failed.length} failed, ${skipped} skipped.`);
  if (failed.length) {
    console.log(JSON.stringify({ baseUrl, failed }, null, 2));
    process.exitCode = 1;
  } else {
    console.log('Media_API_REGRESSION_OK');
  }
}

main().catch((error) => {
  console.error(`Fatal regression-runner error: ${error.stack || error.message}`);
  process.exitCode = 2;
});
