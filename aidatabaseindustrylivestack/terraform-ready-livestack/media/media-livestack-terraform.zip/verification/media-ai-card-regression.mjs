#!/usr/bin/env node
/*
 * Operator-run quality regression for every published Media AI card.
 *
 * This check invokes OCI Generative AI. Ask Data calls are read-only. Agent
 * Console calls are advisory/read-only but add the normal proposed audit rows
 * to AGENT_ACTIONS. Terraform and cloud-init never run this script.
 *
 * Usage:
 *   node verification/media-ai-card-regression.mjs \
 *     --base-url http://PUBLIC_IP:8505
 */

import assert from 'node:assert/strict';
import process from 'node:process';

const PROFILE = 'MEDIA_SELECTAI_V1';
const DEMO_USER = 'admin_jess';

const ASK_DATA_CARDS = [
  {
    question: 'Which live-event or premiere content asset has the highest next-7-day demand and open/cancelled campaign-value exposure?',
    primaryKey: 'CONTENT_ASSET',
    metricKey: 'SEVEN_DAY_PREDICTED_DEMAND',
  },
  {
    question: 'Which content assets are driving the most campaign value this week?',
    primaryKey: 'CONTENT_ASSET',
    metricKey: 'TOTAL_CAMPAIGN_VALUE',
  },
  {
    question: 'Which audience segments have the highest campaign value?',
    primaryKey: 'AUDIENCE_TIER',
    metricKey: 'TOTAL_CAMPAIGN_VALUE',
  },
  {
    question: 'How many audience signal posts have urgency score above 80?',
    countKey: 'AUDIENCE_SIGNAL_POST_COUNT',
    sqlPattern: /urgency_score\s*>=\s*80/i,
    validateRows(rows) {
      assert.ok(Number(rows[0]?.AUDIENCE_SIGNAL_POST_COUNT) > 0,
        'the seeded dataset has no audience signals at or above urgency 80');
      assert.ok(Number(rows[0]?.AVERAGE_URGENCY_SCORE) >= 80,
        'average urgency is below the published threshold');
      assert.ok(Number(rows[0]?.PEAK_URGENCY_SCORE) >= 80,
        'peak urgency is below the published threshold');
    },
  },
  {
    question: 'Which distribution hubs have the most available live-event capacity?',
    primaryKey: 'DISTRIBUTION_HUB',
    metricKey: 'AVAILABLE_CAPACITY_UNITS',
  },
  {
    question: 'Which studios or publishers have the highest average campaign value?',
    primaryKey: 'STUDIO_OR_LABEL',
    metricKey: 'AVERAGE_CAMPAIGN_VALUE',
  },
  {
    question: 'What is the total content revenue from all campaign requests?',
    countKey: 'RECOGNIZED_CONTENT_REVENUE',
  },
  {
    question: 'How many campaign requests have an audience signal source?',
    countKey: 'SIGNAL_DRIVEN_CAMPAIGN_REQUESTS',
  },
  {
    question: 'Which creators are producing the fastest-rising audience signals by platform?',
    primaryKey: 'CREATOR_NAME',
    metricKey: 'RISING_SIGNAL_POST_COUNT',
    sqlPattern: /creator_id\s+IS\s+NOT\s+NULL/i,
    validateRows(rows) {
      assert.ok(rows.every((row) => String(row.CREATOR_NAME || '').trim()),
        'creator momentum returned a null creator name');
      assert.ok(rows.every((row) => String(row.CREATOR_HANDLE || '').trim()),
        'creator momentum returned a null creator handle');
    },
  },
];

const AGENT_CONSOLE_CARDS = [
  {
    team: 'MEDIA_SIGNAL_TEAM',
    question: 'Which content assets are seeing the highest demand right now?',
    primaryKey: 'CONTENT_ASSET',
    metricKey: 'SEVEN_DAY_PREDICTED_DEMAND',
  },
  {
    team: 'MEDIA_REVENUE_TEAM',
    question: 'Show me content revenue by content category',
    primaryKey: 'CONTENT_CATEGORY',
    metricKey: 'TOTAL_CAMPAIGN_VALUE',
  },
  {
    team: 'MEDIA_REVENUE_TEAM',
    question: 'Which live-event or premiere content asset has the highest next-7-day demand and open/cancelled campaign-value exposure?',
    primaryKey: 'CONTENT_ASSET',
    metricKey: 'SEVEN_DAY_PREDICTED_DEMAND',
  },
  {
    team: 'MEDIA_DISTRIBUTION_TEAM',
    question: 'Which content assets have low rights capacity?',
    primaryKey: 'CONTENT_ASSET',
    metricKey: 'AVAILABLE_CAPACITY_UNITS',
  },
  {
    team: 'MEDIA_REVENUE_TEAM',
    question: 'What percentage of campaign requests are audience-signal-driven?',
    countKey: 'SIGNAL_DRIVEN_PERCENTAGE',
  },
  {
    team: 'MEDIA_SIGNAL_TEAM',
    question: 'Find urgent audience-signal posts in the last 24 hours',
    primaryKey: 'CREATOR_HANDLE',
    metricKey: 'URGENCY_SCORE',
    sqlPattern: /urgency_score\s*>=\s*80/i,
    validateRows(rows) {
      assert.ok(rows.length > 0, 'urgent-signals card returned no rows');
      assert.ok(rows.every((row) => Number(row.URGENCY_SCORE) >= 80),
        'urgent-signals card returned a row below urgency 80');
    },
  },
  {
    team: 'MEDIA_DISTRIBUTION_TEAM',
    question: 'Check capacity for Midnight Harbor Premiere Window',
    primaryKey: 'DISTRIBUTION_HUB',
    metricKey: 'AVAILABLE_CAPACITY_UNITS',
  },
  {
    team: 'MEDIA_DISTRIBUTION_TEAM',
    question: 'Find nearest coverage hub with express eight-hour coverage for an audience account in Miami',
    primaryKey: 'DISTRIBUTION_HUB',
    metricKey: 'ESTIMATED_DISTANCE_MI',
    sqlPattern: /FROM\s*\(\s*SELECT[\s\S]*MEDIA_AUDIENCE_ACCOUNTS_V/i,
    validateRows(rows) {
      assert.ok(rows.length > 0, 'Miami express-coverage card returned no nearest hub');
      assert.ok(rows.every((row) => Number(row.MAX_DELIVERY_HRS) <= 8),
        'Miami express-coverage card returned a hub outside the eight-hour contract');
    },
  },
];

function argument(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  return index === -1 ? fallback : process.argv[index + 1] || fallback;
}

const rawBaseUrl = argument('--base-url');
if (!rawBaseUrl) {
  console.error('Usage: node verification/media-ai-card-regression.mjs --base-url http://PUBLIC_IP:8505 [--timeout-ms 360000]');
  process.exit(2);
}

const baseUrl = rawBaseUrl.replace(/\/+$/, '');
const timeoutMs = Number(argument('--timeout-ms', '360000'));
const results = [];

function normalize(value) {
  return String(value ?? '')
    .normalize('NFKD')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function compactNumberText(value) {
  return String(value ?? '').replace(/[^0-9.-]+/g, '');
}

function assertUsableProse(answer, rowCount, label) {
  const text = String(answer || '').trim();
  assert.ok(text.length >= 40, `${label} returned an empty or unusably short answer`);
  assert.doesNotMatch(text, /ADB native AI could not|unexpected response|unable to complete/i,
    `${label} returned a generic AI failure`);
  assert.doesNotMatch(text, /```|\bSQL\s+(?:Query|Used|Statement)\b|\bQuery\s*:/i,
    `${label} exposed SQL/query prose that belongs in the separate SQL panel`);
  if (rowCount > 0) {
    assert.doesNotMatch(text, /no (?:matching |specific )?evidence|insufficient (?:evidence|information)/i,
      `${label} ignored available governed evidence`);
  }
}

function assertReadOnlySql(sql, label) {
  const text = String(sql || '').trim();
  assert.match(text, /^(?:SELECT|WITH)\b/i, `${label} did not return a SELECT/WITH query`);
  assert.doesNotMatch(text, /\b(?:INSERT|UPDATE|DELETE|MERGE|DROP|ALTER|CREATE|GRANT|REVOKE|TRUNCATE|BEGIN|DECLARE|CALL|EXECUTE)\b/i,
    `${label} returned non-read-only SQL`);
}

function assertMetricMention(answer, value, label) {
  if (value === null || value === undefined || value === '') return;
  const compactAnswer = compactNumberText(answer);
  const compactValue = compactNumberText(value);
  assert.ok(compactValue && compactAnswer.includes(compactValue),
    `${label} did not cite the first-row metric ${value}`);
}

function assertFirstRowIsAuthoritative(answer, rows, key, label) {
  if (!key || !rows.length) return;
  const primary = normalize(rows[0]?.[key]);
  assert.ok(primary, `${label} first row has no ${key}`);
  const normalizedAnswer = normalize(answer);
  const primaryIndex = normalizedAnswer.indexOf(primary);
  assert.ok(primaryIndex >= 0, `${label} did not cite first-row ${key}: ${rows[0]?.[key]}`);

  const alternatives = [...new Set(rows.slice(1).map((row) => normalize(row?.[key])))]
    .filter((candidate) => candidate && candidate !== primary);
  for (const alternative of alternatives) {
    const alternativeIndex = normalizedAnswer.indexOf(alternative);
    assert.ok(alternativeIndex < 0 || primaryIndex < alternativeIndex,
      `${label} discussed another ${key} before the authoritative first row`);
  }
}

function assertCardEvidence(card, payload, proseField, label) {
  assert.equal(payload.profile, PROFILE, `${label} used the wrong Select AI profile`);
  assert.equal(payload.readOnly, true, `${label} did not preserve its read-only boundary`);
  assertReadOnlySql(payload.sql, label);
  if (card.sqlPattern) assert.match(payload.sql, card.sqlPattern, `${label} lost its reviewed SQL guard`);
  assert.ok(Array.isArray(payload.rows), `${label} did not return evidence rows`);
  assert.equal(payload.rowCount, payload.rows.length, `${label} rowCount does not match the returned rows`);
  assertUsableProse(payload[proseField], payload.rowCount, label);
  assertFirstRowIsAuthoritative(payload[proseField], payload.rows, card.primaryKey, label);
  if (card.metricKey && payload.rows.length) {
    assertMetricMention(payload[proseField], payload.rows[0]?.[card.metricKey], label);
  }
  if (card.countKey && payload.rows.length) {
    assertMetricMention(payload[proseField], payload.rows[0]?.[card.countKey], label);
  }
  card.validateRows?.(payload.rows);
}

async function post(path, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method: 'POST',
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
        'x-demo-user': DEMO_USER,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`HTTP ${response.status} returned non-JSON content: ${text.slice(0, 300)}`);
    }
    assert.equal(response.status, 200,
      `HTTP ${response.status}: ${JSON.stringify(payload).slice(0, 600)}`);
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

async function run(label, callback) {
  const startedAt = Date.now();
  try {
    await callback();
    results.push({ label, status: 'PASS', elapsedMs: Date.now() - startedAt });
    console.log(`PASS  ${label}`);
  } catch (error) {
    results.push({ label, status: 'FAIL', elapsedMs: Date.now() - startedAt, error: error.message });
    console.error(`FAIL  ${label}: ${error.message}`);
  }
}

for (const [index, card] of ASK_DATA_CARDS.entries()) {
  await run(`Ask Data ${index + 1}/${ASK_DATA_CARDS.length}: ${card.question}`, async () => {
    const runSql = await post('/api/selectai/runsql', {
      question: card.question,
      profile: PROFILE,
    });
    const narrative = await post('/api/selectai/chat', {
      question: card.question,
      profile: PROFILE,
      showSql: true,
      history: [],
    });
    assert.equal(narrative.sql, runSql.sql, 'Narrate and Run SQL used different governed SQL');
    assert.deepEqual(narrative.referencedData?.columns, runSql.columns,
      'Narrate and Run SQL used different evidence columns');
    assert.equal(narrative.referencedData?.row_count, runSql.rowCount,
      'Narrate and Run SQL used different row counts');
    assertCardEvidence(card, { ...runSql, answer: narrative.answer }, 'answer', 'Ask Data card');
  });
}

for (const [index, card] of AGENT_CONSOLE_CARDS.entries()) {
  await run(`Agent Console ${index + 1}/${AGENT_CONSOLE_CARDS.length}: ${card.question}`, async () => {
    const payload = await post('/api/agents/chat', {
      question: card.question,
      profile: PROFILE,
      team: card.team,
    });
    assert.equal(payload.team, card.team, 'published card used the wrong native agent team');
    assert.equal(payload.advisory, true, 'Agent Console did not preserve the advisory boundary');
    assert.equal(payload.actionLogged, true, 'Agent Console did not record its proposed audit entry');
    assertCardEvidence(card, payload, 'response', 'Agent Console card');
  });
}

const failed = results.filter((result) => result.status === 'FAIL');
console.log(`\nMedia AI-card summary: ${results.length - failed.length} passed, ${failed.length} failed.`);
if (failed.length) {
  console.log(JSON.stringify({ baseUrl, failed }, null, 2));
  process.exitCode = 1;
} else {
  console.log('MEDIA_AI_CARD_REGRESSION_OK');
}
