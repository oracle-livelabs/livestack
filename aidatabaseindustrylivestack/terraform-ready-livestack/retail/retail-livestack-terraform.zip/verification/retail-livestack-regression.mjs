#!/usr/bin/env node
/*
 * Safe operator-run regression for a deployed Retail LiveStack.
 *
 * The default suite only reads health, metadata, and seeded demo data. Adding
 * --include-ai sends one read-only Ask Data request. Adding
 * --include-agent-chat sends one advisory Agent Console request, which can add
 * a proposed audit entry. Neither option imports, restores, or changes the
 * Retail dataset.
 *
 * Usage:
 *   node retail-livestack-regression.mjs --base-url http://host:8505
 *   node retail-livestack-regression.mjs --base-url http://host:8505 --include-ai
 *   node retail-livestack-regression.mjs --base-url http://host:8505 --include-agent-chat
 */

import assert from 'node:assert/strict';
import process from 'node:process';

function argument(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  return index === -1 ? fallback : process.argv[index + 1] || fallback;
}

const rawBaseUrl = argument('--base-url');
if (!rawBaseUrl) {
  console.error('Usage: node retail-livestack-regression.mjs --base-url http://host:8505 [--include-ai] [--include-agent-chat]');
  process.exit(2);
}

const baseUrl = rawBaseUrl.replace(/\/+$/, '');
const timeoutMs = Number(argument('--timeout-ms', '120000'));
const agentTimeoutMs = Number(argument('--agent-timeout-ms', '300000'));
const runAi = process.argv.includes('--include-ai') || process.argv.includes('--include-agent-chat');
const runAgentChat = process.argv.includes('--include-agent-chat');
const results = [];
const demoUser = 'admin_jess';

function value(object, ...keys) {
  return keys.map((key) => object?.[key]).find((candidate) => candidate !== undefined && candidate !== null);
}

function nonEmptyArray(payload, label) {
  assert.ok(Array.isArray(payload), `${label} must be an array`);
  assert.ok(payload.length > 0, `${label} must not be empty`);
  return payload;
}

async function request(label, path, {
  method = 'GET', body, timeout = timeoutMs, headers = {}, expectedStatus = 200,
} = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method,
      headers: {
        accept: 'application/json',
        'x-demo-user': demoUser,
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`${label} returned non-JSON content: ${text.slice(0, 240)}`);
    }
    assert.equal(response.status, expectedStatus, `${label} returned HTTP ${response.status}: ${JSON.stringify(payload).slice(0, 500)}`);
    return { payload, response };
  } finally {
    clearTimeout(timer);
  }
}

async function requestText(label, path, { timeout = timeoutMs } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(new URL(path, `${baseUrl}/`), {
      headers: { accept: 'text/html,application/javascript,text/css,*/*' },
      signal: controller.signal,
    });
    const text = await response.text();
    assert.equal(
      response.status,
      200,
      `${label} returned HTTP ${response.status}: ${text.slice(0, 240)}`,
    );
    return { response, text };
  } finally {
    clearTimeout(timer);
  }
}

async function test(label, callback) {
  const started = Date.now();
  try {
    await callback();
    results.push({ label, status: 'PASS', elapsedMs: Date.now() - started });
    console.log(`PASS  ${label}`);
  } catch (error) {
    results.push({ label, status: 'FAIL', elapsedMs: Date.now() - started, error: error.message });
    console.error(`FAIL  ${label}: ${error.message}`);
  }
}

async function validateReadOnlyDemoPersona() {
  const { payload: users } = await request('demo users', '/api/users');
  const user = nonEmptyArray(users, 'demo users')
    .find((candidate) => value(candidate, 'USERNAME', 'username') === demoUser);
  assert.ok(user, `demo persona ${demoUser} is unavailable`);
  assert.equal(String(value(user, 'ROLE', 'role')).toLowerCase(), 'admin');
}

async function main() {
  await test('frontend HTML and built assets are browser-loadable', async () => {
    const { response, text: html } = await requestText('frontend HTML', '/');
    assert.match(html, /<div id="root"><\/div>/, 'frontend HTML has no React root');

    const csp = response.headers.get('content-security-policy') || '';
    if (new URL(baseUrl).protocol === 'http:') {
      assert.ok(
        !/upgrade-insecure-requests/i.test(csp),
        'HTTP frontend CSP upgrades its assets to unsupported HTTPS',
      );
    }

    const scriptPath = html.match(/src="([^"?]*\/assets\/[^"?]+[.]js)"/)?.[1];
    const stylesheetPath = html.match(/href="([^"?]*\/assets\/[^"?]+[.]css)"/)?.[1];
    assert.ok(scriptPath, 'frontend HTML has no built JavaScript asset');
    assert.ok(stylesheetPath, 'frontend HTML has no built stylesheet asset');
    await requestText('frontend JavaScript asset', scriptPath);
    await requestText('frontend stylesheet asset', stylesheetPath);
    await requestText('Oracle JET bootstrap asset', '/jet/bootstrap.js');
  });

  await test('connection: API health queries ADB', async () => {
    const { payload } = await request('API health', '/api/health');
    assert.equal(payload.status, 'healthy');
    assert.equal(String(value(payload.database, 'STATUS', 'status')).toLowerCase(), 'connected');
  });

  await test('governed admin persona is available', validateReadOnlyDemoPersona);

  await test('Retail network graph page endpoints', async () => {
    const { payload: influencers } = await request(
      'Retail graph influencers',
      '/api/graph/influencers?limit=1',
    );
    const influencer = nonEmptyArray(influencers, 'Retail graph influencers')[0];
    const influencerId = value(influencer, 'INFLUENCER_ID', 'influencer_id');
    assert.ok(influencerId, 'Retail graph influencer has no identifier');
    const { payload: network } = await request(
      'Retail graph network',
      `/api/graph/network/${encodeURIComponent(influencerId)}?depth=1`,
    );
    assert.equal(typeof network.center, 'object', 'Retail graph network has no center');
    nonEmptyArray(network.nodes, 'Retail graph nodes');
    assert.ok(Array.isArray(network.edges), 'Retail graph edges must be an array');
  });

  const simpleGetTests = [
    ['seeded Retail demo status', '/api/demo/status', (body) => assert.equal(typeof body, 'object')],
    ['dashboard summary', '/api/dashboard/summary', (body) => assert.equal(typeof body, 'object')],
    ['Retail capacity KPIs', '/api/fulfillment/kpis', (body) => assert.equal(typeof body, 'object')],
    ['Retail OML summary', '/api/ml/summary', (body) => assert.equal(typeof body, 'object')],
    ['Select AI profile metadata', '/api/selectai/profiles', (body) => {
      const profiles = nonEmptyArray(body.profiles, 'Select AI profiles');
      assert.ok(profiles.some((profile) => value(profile, 'name', 'NAME') === 'RETAIL_SELECTAI_V1'));
    }],
    ['Select AI curated schema', '/api/selectai/schema-objects', (body) => nonEmptyArray(body.objects, 'Select AI schema objects')],
    ['Select AI readiness', '/api/selectai/health', (body) => assert.equal(body.status, 'healthy')],
    ['native agent profiles', '/api/agents/profiles', (body) => assert.equal(typeof body, 'object')],
    ['governed Agent Console teams', '/api/agents/teams', (body) => {
      const teams = nonEmptyArray(body, 'governed Agent Console teams').map((team) => value(team, 'TEAM_NAME', 'team_name', 'name'));
      for (const team of ['DEMAND_SIGNAL_AGENT', 'FULFILLMENT_OPTIMIZATION_AGENT', 'COMMERCE_INTELLIGENCE_AGENT', 'RETURNS_TRIAGE_AGENT']) {
        assert.ok(teams.includes(team), `governed agent team ${team} is missing`);
      }
    }],
    ['Returns hybrid-search readiness', '/api/returns/evidence-readiness', (body) => {
      assert.equal(body.available, true, 'Returns Vector evidence is not active');
      assert.equal(body.vectorIndexValid, true, 'Returns Vector index is not valid');
      assert.equal(body.vectorModel, 'ALL_MINILM_L12_V2');
      assert.equal(body.dimensions, 384);
    }],
    ['Returns application audit readiness', '/api/returns/audit-readiness', (body) => {
      assert.equal(body.available, true, 'application audit evidence is not active');
      assert.equal(body.feature, 'APP_AUDIT_TRAIL');
    }],
    ['agent audit history', '/api/agents/actions?limit=3', (body) => assert.ok(Array.isArray(body), 'agent audit history must be an array')],
  ];

  for (const [label, path, assertion] of simpleGetTests) {
    await test(label, async () => {
      const { payload } = await request(label, path);
      assertion(payload);
    });
  }

  if (runAi) {
    await test('governed Ask Data SQL', async () => {
      const { payload } = await request('governed Ask Data SQL', '/api/selectai/runsql', {
        method: 'POST',
        body: { question: 'What are the top products by revenue?' },
        timeout: agentTimeoutMs,
      });
      assert.equal(typeof payload.sql, 'string', 'Ask Data did not return generated SQL');
      assert.ok(Array.isArray(payload.rows), 'Ask Data did not return a row array');
      assert.equal(payload.readOnly, true, 'Ask Data did not preserve the read-only boundary');
    });
  } else {
    results.push({ label: 'governed Ask Data SQL', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  governed Ask Data SQL (use --include-ai to run one live Select AI request)');
  }

  if (runAgentChat) {
    await test('governed Agent Console advisory', async () => {
      const { payload } = await request('governed Agent Console advisory', '/api/agents/chat', {
        method: 'POST',
        body: {
          question: 'Which product sales revenue needs attention?',
        },
        timeout: agentTimeoutMs,
      });
      assert.equal(typeof payload.response, 'string', 'Agent Console returned no advisory response');
      assert.equal(payload.team, 'COMMERCE_INTELLIGENCE_AGENT', 'Agent Console did not use the Commerce specialist');
      assert.equal(payload.security?.readOnly, true, 'Agent Console did not preserve the read-only boundary');
      assert.equal(payload.security?.mutationPerformed, false, 'Agent Console performed an unexpected mutation');
      assert.equal(payload.agentUsed, true, 'Agent Console did not use native AI synthesis');
    });
  } else {
    results.push({ label: 'governed Agent Console advisory', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  governed Agent Console advisory (use --include-agent-chat; it can add one proposed audit entry)');
  }

  const passed = results.filter((result) => result.status === 'PASS').length;
  const failed = results.filter((result) => result.status === 'FAIL');
  const skipped = results.filter((result) => result.status === 'SKIP').length;
  console.log(`\nRetail regression summary: ${passed} passed, ${failed.length} failed, ${skipped} skipped.`);
  if (failed.length) {
    console.log(JSON.stringify({ baseUrl, failed }, null, 2));
    process.exitCode = 1;
  } else {
    console.log('Retail_API_REGRESSION_OK');
  }
}

main().catch((error) => {
  console.error(`Fatal regression-runner error: ${error.stack || error.message}`);
  process.exitCode = 2;
});
