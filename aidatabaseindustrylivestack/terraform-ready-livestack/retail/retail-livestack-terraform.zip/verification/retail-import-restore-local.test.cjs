'use strict';

// Local source-level regression tests. No database, containers, network, or
// application dataset is touched. Oracle commit/readiness semantics require a
// separate live acceptance test; mocked execute() results do not prove them.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');

const applicationRoot = process.env.RETAIL_APPLICATION_ROOT
  || path.resolve(__dirname, '../application');
const workflowPath = path.join(applicationRoot, 'backend/lib/importWorkflowService.js');
const inMemoryPath = path.join(applicationRoot, 'backend/lib/inMemoryEvidenceService.js');
const workflow = fs.readFileSync(workflowPath, 'utf8');

// Compile the real, unexported source functions without loading the importer’s
// external packages or the real Oracle client. No function implementation is
// duplicated in this test file.
function sourceFunction(name) {
  const start = workflow.search(new RegExp(`^(?:async )?function ${name}\\(`, 'm'));
  assert.notEqual(start, -1, `Missing source function ${name}`);
  const end = workflow.indexOf('\n}\n', start);
  assert.notEqual(end, -1, `Missing closing brace for ${name}`);
  return workflow.slice(start, end + 2);
}

function loadWorkflowFunctions(names, dependencies = {}) {
  const context = vm.createContext({
    ...dependencies,
    crypto,
    ImportError: class ImportError extends Error {},
  });
  return vm.runInContext(
    `${names.map(sourceFunction).join('\n')}\n({${names.join(',')}});`,
    context,
    { filename: workflowPath },
  );
}

const parser = loadWorkflowFunctions([
  'normalizeSourceId',
  'parseSourceIdList',
  'parseColumnValue',
]);
const plain = (value) => JSON.parse(JSON.stringify(value));

test('source-ID parser retains comma-separated and empty input behavior', () => {
  assert.deepEqual(plain(parser.parseSourceIdList(' 1, 3,abc ')), ['1', '3', 'abc']);
  assert.deepEqual(plain(parser.parseSourceIdList('1,,3,')), ['1', '3']);
  assert.equal(parser.parseSourceIdList('  '), null);
});

test('source-ID parser accepts numeric/string JSON arrays and empty arrays', () => {
  assert.deepEqual(plain(parser.parseSourceIdList('[1,3]')), ['1', '3']);
  assert.deepEqual(plain(parser.parseSourceIdList('["1"," 3 "]')), ['1', '3']);
  assert.deepEqual(plain(parser.parseSourceIdList('[]')), []);
  assert.deepEqual(plain(parser.parseSourceIdList('[0,9007199254740991]')), ['0', '9007199254740991']);
});

test('source-ID parser rejects malformed or non-scalar JSON array members', () => {
  for (const input of [
    '[null]', '[[1]]', '[true]', '[{}]', '[""]', '["  "]',
    '[1.5]', '[9007199254740992]', '[1,', '[1,]',
  ]) {
    assert.throws(() => parser.parseSourceIdList(input), undefined, input);
  }
});

test('CSV normalization reports invalid arrays with table, line, and column', () => {
  const errors = [];
  const value = parser.parseColumnValue(
    { name: 'social_posts' },
    { name: 'detected_products', type: 'source_id_list' },
    '[null]', 12, errors,
  );
  assert.equal(value, null);
  assert.equal(errors.length, 1);
  assert.match(errors[0], /social_posts\.csv line 12/);
  assert.match(errors[0], /"detected_products"/);
  assert.match(errors[0], /comma-separated.*JSON array/);
});

test('CSV normalization accepts supported ID-list formats without warnings', () => {
  for (const input of ['1,3', '[1,3]', '["1","3"]']) {
    const errors = [];
    assert.deepEqual(plain(parser.parseColumnValue(
      { name: 'social_posts' },
      { name: 'detected_products', type: 'source_id_list' },
      input, 2, errors,
    )), ['1', '3']);
    assert.deepEqual(errors, []);
  }
});

function loadInMemory(db) {
  const module = { exports: {} };
  const context = vm.createContext({
    module,
    exports: module.exports,
    require(id) {
      if (id === 'crypto') return crypto;
      if (id === '../config/database') return db;
      throw new Error(`Unexpected dependency ${id}`);
    },
  });
  vm.runInContext(fs.readFileSync(inMemoryPath, 'utf8'), context, { filename: inMemoryPath });
  return module.exports;
}

function makeInMemoryHarness({ incompleteSnapshots = 0, populationError = null, checkoutError = null } = {}) {
  const calls = [];
  let snapshots = 0;
  let sleeps = 0;
  let evidenceWrites = 0;
  const populationConnection = {
    async execute(sql, binds, options) {
      calls.push({ connection: 'population', sql, options });
      assert.match(sql, /DBMS_INMEMORY\.POPULATE/);
      assert.equal(options.autoCommit, false);
      if (populationError) throw populationError;
      return {};
    },
  };
  const callerConnection = {
    async execute(sql, binds, options) {
      calls.push({ connection: 'caller', sql, options });
      assert.doesNotMatch(sql, /DBMS_INMEMORY\.POPULATE/, 'POPULATE must not use the dataset transaction');
      assert.equal(options.autoCommit, false);
      if (/SELECT prev_sql_id/.test(sql)) {
        return { rows: [{ PREV_SQL_ID: 'abc123def4567', PREV_CHILD_NUMBER: 0 }] };
      }
      if (/DBMS_XPLAN\.DISPLAY_CURSOR/.test(sql)) {
        return { rows: [{ PLAN_TABLE_OUTPUT: 'TABLE ACCESS INMEMORY FULL' }] };
      }
      if (/FROM v\$sql_plan/.test(sql)) {
        return { rows: [{ OBJECT_OWNER: 'APP_USER', OBJECT_NAME: 'ORDERS' }] };
      }
      if (/SELECT segment_name, table_inmemory/.test(sql)) {
        snapshots += 1;
        return { rows: ['ORDERS', 'ORDER_ITEMS', 'SOCIAL_POSTS', 'CUSTOMERS', 'DEMAND_FORECASTS'].map((name) => ({
          SEGMENT_NAME: name,
          TABLE_INMEMORY: 'ENABLED',
          POPULATE_STATUS: snapshots <= incompleteSnapshots ? 'STARTED' : 'COMPLETED',
          INMEMORY_BYTES: 100,
          BYTES_NOT_POPULATED: snapshots <= incompleteSnapshots ? 1 : 0,
        })) };
      }
      if (/DBMS_SESSION\.SLEEP\(1\)/.test(sql) && !/DECLARE populated_count/.test(sql)) sleeps += 1;
      if (/MERGE INTO app_inmemory_generation_evidence/.test(sql)) evidenceWrites += 1;
      return {};
    },
    async commit() { throw new Error('The proof must not commit the dataset transaction'); },
  };
  const db = {
    oracledb: { OUT_FORMAT_OBJECT: 4002 },
    async getConnection() {
      calls.push({ action: 'checkout' });
      if (checkoutError) throw checkoutError;
      return populationConnection;
    },
    async releaseConnection(connection, options) {
      calls.push({ action: 'release', connection, options });
      assert.equal(connection, checkoutError ? undefined : populationConnection);
      assert.equal(options.rollback, true);
    },
  };
  const service = loadInMemory(db);
  return {
    run() {
      return service.proveInMemoryOnConnection(callerConnection, {
        generationId: 'test_generation', jobId: 'local-test',
        datasetFingerprint: 'a'.repeat(64), proofId: 'local-proof',
      });
    },
    calls,
    get snapshots() { return snapshots; },
    get sleeps() { return sleeps; },
    get evidenceWrites() { return evidenceWrites; },
  };
}

test('In-Memory population uses and releases a separate maintenance connection', async () => {
  const harness = makeInMemoryHarness();
  const proof = await harness.run();
  assert.equal(proof.populatedSegments, 5);
  assert.equal(harness.evidenceWrites, 1);
  const populationIndex = harness.calls.findIndex((call) => call.connection === 'population');
  const releaseIndex = harness.calls.findIndex((call) => call.action === 'release');
  const callerIndex = harness.calls.findIndex((call) => call.connection === 'caller');
  assert.ok(populationIndex >= 0 && releaseIndex > populationIndex && callerIndex > releaseIndex);
});

test('In-Memory final snapshot retries a transient incomplete population', async () => {
  const harness = makeInMemoryHarness({ incompleteSnapshots: 2 });
  await harness.run();
  assert.equal(harness.snapshots, 3);
  assert.equal(harness.sleeps, 2);
  assert.equal(harness.evidenceWrites, 1);
});

test('In-Memory incomplete final population exhausts retries without ready evidence', async () => {
  const harness = makeInMemoryHarness({ incompleteSnapshots: 100 });
  await assert.rejects(harness.run(), /COMPLETED.*positive.*In-Memory bytes/);
  assert.equal(harness.snapshots, 60);
  assert.equal(harness.sleeps, 59);
  assert.equal(harness.evidenceWrites, 0);
});

test('In-Memory population failure releases its connection and writes no evidence', async () => {
  const error = new Error('local population failure');
  const harness = makeInMemoryHarness({ populationError: error });
  await assert.rejects(harness.run(), (actual) => actual === error);
  assert.equal(harness.calls.filter((call) => call.action === 'release').length, 1);
  assert.equal(harness.calls.filter((call) => call.connection === 'caller').length, 0);
  assert.equal(harness.evidenceWrites, 0);
});

test('In-Memory checkout failure does not start dataset proof work', async () => {
  const error = new Error('local pool exhausted');
  const harness = makeInMemoryHarness({ checkoutError: error });
  await assert.rejects(harness.run(), (actual) => actual === error);
  assert.equal(harness.calls.filter((call) => call.connection === 'caller').length, 0);
  assert.equal(harness.evidenceWrites, 0);
});

test('trusted-context lookup uses current-session ALL_CONTEXT with Retail ownership checks', () => {
  assert.match(workflow, /FROM all_context\s+WHERE namespace = 'RETAIL_APP_CTX'\s+AND schema = USER\s+AND package = 'RETAIL_SECURITY_PKG'/);
  assert.doesNotMatch(workflow, /FROM dba_context/i);
});

async function mockedVpdProof({
  expected = 0, regional = expected, admin = 12, outOfScope = 0,
  restricted = 0, policyCount = 4, denialErrorNum = 28115,
} = {}) {
  let persona = 'admin_jess';
  let rollbackCount = 0;
  const functions = loadWorkflowFunctions(['oracleErrorNumber', 'proveVpdReadiness'], {
    db: { async setSecurityContext(connection, user) { persona = user; } },
    async execSql(connection, sql) {
      if (/SYS_CONTEXT\('RETAIL_APP_CTX', 'AUTHENTICATED'\)/.test(sql)) {
        assert.match(sql, /expected_regional_orders/);
        assert.match(sql, /UPPER\(center.state_province\) = 'CALIFORNIA'/);
        assert.match(sql, /UPPER\(customer.state_province\) = 'CALIFORNIA'/);
        return { rows: [{
          AUTHENTICATED: 'Y', ROLE_NAME: 'admin', ACCESS_SCOPE: 'GLOBAL',
          VISIBLE_ORDERS: admin, EXPECTED_REGIONAL_ORDERS: expected,
          EXPECTED_PROTECTED_OBJECT_COUNT: 2, EXPECTED_POLICY_COUNT: 4,
          POLICY_COUNT: policyCount, PROTECTED_OBJECT_COUNT: 2,
          SELECT_POLICY_COUNT: 2, CHECKED_WRITE_POLICY_COUNT: 4,
        }] };
      }
      if (/out_of_scope_orders/.test(sql)) {
        assert.equal(persona, 'fm_west_maria');
        return { rows: [{ VISIBLE_ORDERS: regional, OUT_OF_SCOPE_ORDERS: outOfScope }] };
      }
      if (/SELECT COUNT\(\*\) visible_orders FROM orders/.test(sql)) {
        assert.equal(persona, 'viewer_sam');
        return { rows: [{ VISIBLE_ORDERS: restricted }] };
      }
      if (/SELECT MIN\(return_id\)/.test(sql)) return { rows: [{ RETURN_ID: 1 }] };
      if (/INSERT INTO return_decisions/.test(sql)) {
        if (persona === 'analyst_raj' && denialErrorNum) {
          const error = new Error(`ORA-${denialErrorNum}: local denied-write fixture`);
          error.errorNum = denialErrorNum;
          throw error;
        }
        return { rowsAffected: 1 };
      }
      if (/ROLLBACK TO/.test(sql)) rollbackCount += 1;
      return {};
    },
  });
  const proof = await functions.proveVpdReadiness({}, { generationId: 'local-test' });
  assert.equal(persona, 'admin_jess');
  assert.equal(rollbackCount, 2, 'both allowed and denied probe writes must be rolled back');
  return proof;
}

test('VPD proof accepts correctly empty regional scope for a non-California dataset', async () => {
  assert.equal((await mockedVpdProof({ expected: 0, regional: 0 })).ready, true);
});

test('VPD proof accepts an all-California dataset when expected visibility equals Admin', async () => {
  assert.equal((await mockedVpdProof({ expected: 12, regional: 12 })).ready, true);
});

test('VPD proof still rejects mismatched visibility, leakage, restricted access, or missing policies', async () => {
  for (const options of [
    { expected: 2, regional: 1 }, { expected: 2, regional: 3 },
    { expected: 2, regional: 2, outOfScope: 1 },
    { expected: 2, regional: 2, restricted: 1 },
    { expected: 2, regional: 2, policyCount: 3 },
  ]) assert.equal((await mockedVpdProof(options)).ready, false, JSON.stringify(options));
});

test('VPD proof still requires the precise ORA-28115 denied-write result', async () => {
  await assert.rejects(mockedVpdProof({ denialErrorNum: 0 }), /not denied.*ORA-28115/);
  await assert.rejects(mockedVpdProof({ denialErrorNum: 942 }), /ORA-942/);
});
