#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APPLICATION_ROOT="${SOURCE_ROOT}/application"
TEMP_APPLICATION_ROOT=""

fail() {
  printf 'FAIL: %s\n' "$*" >&2
  exit 1
}

cleanup() {
  if [[ -n "${TEMP_APPLICATION_ROOT}" && -d "${TEMP_APPLICATION_ROOT}" ]]; then
    rm -rf -- "${TEMP_APPLICATION_ROOT}"
  fi
}
trap cleanup EXIT

if [[ ! -d "${APPLICATION_ROOT}" ]]; then
  command -v unzip >/dev/null 2>&1 ||
    fail "unzip is required to inspect the packaged application payload."
  TEMP_APPLICATION_ROOT="$(mktemp -d)"
  unzip -q "${SOURCE_ROOT}/payload/retail-application.zip" -d "${TEMP_APPLICATION_ROOT}"
  APPLICATION_ROOT="${TEMP_APPLICATION_ROOT}"
fi

require_pattern() {
  local pattern="$1"
  local path="$2"
  grep -Eq "${pattern}" "${SOURCE_ROOT}/${path}" ||
    fail "${path} is missing required contract pattern: ${pattern}"
}

require_application_pattern() {
  local pattern="$1"
  local path="$2"
  grep -Eq "${pattern}" "${APPLICATION_ROOT}/${path}" ||
    fail "application/${path} is missing required contract pattern: ${pattern}"
}

# A data value can legitimately equal a network port (for example a social
# reach count of 11434), so reject actual local-model identifiers rather than
# an arbitrary number that would create false positives in the demo dataset.
forbidden_runtime_pattern='olla''ma|llama3[.]2'
if grep -ERin \
  --exclude='check-selectai-platform-contract.sh' \
  --exclude='check-resource-manager-package.py' \
  --exclude='build_resource_manager_package.py' \
  --exclude='*.zip' \
  --exclude-dir='application' \
  --exclude-dir='local-compose-reference' \
  --exclude-dir='.terraform' \
  --exclude-dir='__pycache__' \
  "${forbidden_runtime_pattern}" "${SOURCE_ROOT}" >/dev/null; then
  grep -ERin \
    --exclude='check-selectai-platform-contract.sh' \
    --exclude='check-resource-manager-package.py' \
    --exclude='build_resource_manager_package.py' \
    --exclude='*.zip' \
    --exclude-dir='application' \
    --exclude-dir='local-compose-reference' \
    --exclude-dir='.terraform' \
    --exclude-dir='__pycache__' \
    "${forbidden_runtime_pattern}" "${SOURCE_ROOT}" >&2 || true
  fail "Shipped source still contains a local-model runtime reference."
fi

if grep -ERin "${forbidden_runtime_pattern}" "${APPLICATION_ROOT}" >/dev/null; then
  # When the expanded conversion source is available it retains a deliberately
  # excluded local-Compose reference.  Keep this allowlist exactly aligned
  # with PAYLOAD_EXCLUDES; check-resource-manager-package.py still scans the
  # immutable payload itself with no such exceptions.
  local_reference_hits="$(
    grep -ERin \
      --exclude='ollamaAssistant.js' \
      --exclude='pull_ollama.sh' \
      --exclude='podman-stack.sh' \
      --exclude='bootstrap_db.sh' \
      --exclude='enable_ords_schema.sh' \
      --exclude='bootstrap-retail-adb.sh' \
      --exclude='compose.yml' \
      --exclude='README.md' \
      --exclude='.env.example' \
      --exclude='00_setup.sql' \
      --exclude='07_ai_profile.sql' \
      --exclude='08_agents.sql' \
      --exclude='16_retail_unified_audit_admin.sql' \
      "${forbidden_runtime_pattern}" "${APPLICATION_ROOT}" || true
  )"
  if [[ -n "${local_reference_hits}" ]]; then
    printf '%s\n' "${local_reference_hits}" >&2
    fail "Managed application source still contains a local-model runtime reference."
  fi
fi

if grep -ERn \
  --include='*.tf' \
  --include='*.yaml' \
  --include='*.yml' \
  'BEGIN (RSA )?PRIVATE KEY|private_key(_b64)?[[:space:]]*=' \
  "${SOURCE_ROOT}" >/dev/null; then
  fail "Terraform or metadata contains OCI private-key material or an input path for it."
fi

require_pattern '"scripts/pull_ollama.sh"' "scripts/build_resource_manager_package.py"
require_pattern '"backend/lib/ollamaAssistant.js"' "scripts/build_resource_manager_package.py"

require_pattern 'variable "tenancy_ocid"' "variables.tf"
require_pattern 'variable "current_user_ocid"' "variables.tf"
require_pattern 'variable "identity_domain_ocid"' "variables.tf"
require_pattern 'variable "bootstrap_generation"' "variables.tf"
require_pattern 'version[[:space:]]*=[[:space:]]*"=[[:space:]]*8[.]25[.]0"' "versions.tf"
require_pattern 'version[[:space:]]*=[[:space:]]*"=[[:space:]]*3[.]9[.]0"' "versions.tf"
require_pattern 'payload/retail-application[.]zip' "main.tf"
require_pattern 'filesha256[(]local[.]application_payload_path[)]' "main.tf"
require_pattern 'filesha256[(]"\$\{path[.]module\}/compute-app[.]tf"[)]' "main.tf"
require_pattern 'filesha256[(]"\$\{path[.]module\}/object-storage[.]tf"[)]' "main.tf"
require_pattern 'source[[:space:]]*=[[:space:]]*local[.]application_payload_path' "object-storage.tf"
require_pattern 'for_each[[:space:]]*=[[:space:]]*toset[(]\[local[.]application_payload_sha256\]\)' "object-storage.tf"
require_pattern 'object[[:space:]]*=[[:space:]]*"application/payloads/\$\{each[.]key\}[.]zip"' "object-storage.tf"
require_pattern 'oci_objectstorage_object[.]application\[local[.]application_payload_sha256\][.]object' "object-storage.tf"
require_pattern 'base64gzip[(]local[.]application_cloud_init[)]' "compute-app.tf"
require_pattern 'application_instance_metadata_budget_bytes[[:space:]]*=[[:space:]]*30000' "compute-app.tf"
require_pattern 'application_metadata_size_bytes[[:space:]]*<=' "compute-app.tf"
require_pattern 'maxLength:[[:space:]]*4096' "schema.yaml"
require_pattern 'version:[[:space:]]*"20260812-v1"' "schema.yaml"
require_pattern 'type:[[:space:]]*oci:identity:domains:id' "schema.yaml"
require_pattern 'data "oci_identity_domain" "selected"' "select-ai-key.tf"
require_pattern 'data "oci_identity_domains_my_api_keys" "current"' "select-ai-key.tf"
require_pattern 'resource "oci_identity_domains_my_api_key" "select_ai"' "select-ai-key.tf"
require_pattern 'urn:ietf:params:scim:schemas:oracle:idcs:apikey' "select-ai-key.tf"
require_pattern 'total_results[[:space:]]*<[[:space:]]*3' "select-ai-key.tf"
require_pattern 'selectai_api_key_owner_token[[:space:]]*=[[:space:]]*substr[(]sha256[(]jsonencode' "select-ai-key.tf"
require_pattern 'self[.]user\[0\][.]ocid[[:space:]]*==[[:space:]]*var[.]current_user_ocid' "select-ai-key.tf"
require_pattern 'self[.]domain_ocid[[:space:]]*==[[:space:]]*var[.]identity_domain_ocid' "select-ai-key.tf"
require_pattern 'data "oci_objectstorage_object" "api_key_public_callback"' "select-ai-key.tf"
require_pattern 'EXPECTED_DEPLOYMENT_ID' "select-ai-key.tf"
require_pattern 'EXPECTED_INSTANCE_OCID' "select-ai-key.tf"
require_pattern 'terraform_data[.]api_key_activation' "bootstrap-wait.tf"
require_application_pattern 'RETAIL_NATIVE_AI_ACCEPTANCE_OK' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'RETAIL_ADB_ACCEPTANCE_OK' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'DBCC CREATE RETAIL_GENAI_KEY_V1' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'FROM user_credentials' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'RETAIL_NATIVE_AI_WRAPPER_CHAT_OK' "deployment/retail-native-ai-bootstrap.sql"
require_application_pattern 'RETAIL_NATIVE_AI_SHOWSQL_GATE_OK' "deployment/retail-native-ai-bootstrap.sql"
require_application_pattern 'FUNCTION normalize_show_sql' "deployment/retail-native-ai-bootstrap.sql"
require_application_pattern 'inventory risk.*allterrain hiking boots' "backend/lib/nativeRetailAi.js"
require_application_pattern "UPPER\\(product_name\\) = UPPER\\('AllTerrain Hiking Boots'\\)" "backend/lib/nativeRetailAi.js"
native_ai_bootstrap_sql="${APPLICATION_ROOT}/deployment/retail-native-ai-bootstrap.sql"
native_ai_ready_line="$(grep -n '^[[:space:]]*mark_ready;' "${native_ai_bootstrap_sql}" | head -n 1 | cut -d: -f1)"
native_ai_wrapper_line="$(grep -n 'RETAIL_NATIVE_AI_WRAPPER_CHAT_OK' "${native_ai_bootstrap_sql}" | head -n 1 | cut -d: -f1)"
[[ -n "${native_ai_ready_line}" && -n "${native_ai_wrapper_line}" ]] ||
  fail "Native Select AI readiness sequencing markers are missing."
if (( native_ai_ready_line >= native_ai_wrapper_line )); then
  fail "Native Select AI must be marked ready before its managed wrapper acceptance probe."
fi
require_application_pattern 'GRANT EXECUTE ON DBMS_CLOUD TO APP_USER' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'GRANT EXECUTE ON DBMS_CLOUD_AI TO APP_USER' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'GRANT EXECUTE ON DBMS_CLOUD_AI_AGENT TO APP_USER' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'RETAIL_RM_READINESS_OK' "deployment/retail-rm-readiness.sql"
require_application_pattern 'AGENT_ACTIONS_AND_EVENT_STREAM' "deployment/retail-rm-readiness.sql"
require_application_pattern 'FROM all_context' "deployment/retail-rm-readiness.sql"
validation_context_line="$(awk '/validation_driver=/{in_validation=1} in_validation && /RETAIL_SECURITY_PKG[.]set_user_context[('"'"'admin_jess'"'"')]/ { print NR; exit }' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh")"
validation_readiness_line="$(awk '/validation_driver=/{in_validation=1} in_validation && /FROM app_dataset_readiness/ { print NR; exit }' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh")"
[[ -n "${validation_context_line}" && -n "${validation_readiness_line}" ]] ||
  fail "Retail validation must establish its VPD context before checking readiness."
if (( validation_context_line >= validation_readiness_line )); then
  fail "Retail validation checks VPD-protected readiness before setting the admin context."
fi
require_application_pattern 'RETAIL_EMBEDDING_MODEL_READY' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'RETAIL_SCHEMA_DATA_COMPILE_OK' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'RETAIL_SCHEMA_FINALIZE_COMPILE_OK' "deployment/bootstrap-retail-rm-adb.sh"
if grep -Eqi '^[[:space:]]*COMMENT ON (TABLE|COLUMN)[[:space:]]+social_post_payloads' \
  "${APPLICATION_ROOT}/db/schema/09_comments.sql"; then
  fail "Retail comments still target the deliberately removed SOCIAL_POST_PAYLOADS table."
fi
dataset_loader_line="$(grep -n '@"\${data_loader_sql}"' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh" | head -n 1 | cut -d: -f1)"
dataset_lifecycle_line="$(grep -n '@"\${SCHEMA_DIR}/17_retail_dataset_lifecycle.sql"' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh" | head -n 1 | cut -d: -f1)"
vector_finalize_line="$(grep -n '@"\${DATA_DIR}/finalize_vector_search.sql"' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh" | head -n 1 | cut -d: -f1)"
[[ -n "${dataset_loader_line}" && -n "${dataset_lifecycle_line}" && -n "${vector_finalize_line}" ]] ||
  fail "Retail dataset lifecycle ordering markers are missing."
if (( dataset_loader_line >= dataset_lifecycle_line || dataset_lifecycle_line >= vector_finalize_line )); then
  fail "Retail must initialize dataset lifecycle state after loading data and before vector finalization."
fi
require_application_pattern 'security_context_sql="\$\{work_dir\}/06a-retail-app-context-admin[.]sql"' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern '@"\$\{security_context_sql\}" APP_USER' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'Retail context fragment retained an EXIT command' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'ALTER VIEW retail_return_workbench_v COMPILE' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'FROM \(SELECT data FROM products_inventory_dv FETCH FIRST 1 ROW ONLY\)' "deployment/bootstrap-retail-rm-adb.sh"
require_application_pattern 'FROM \(SELECT data FROM orders_dv FETCH FIRST 1 ROW ONLY\)' "deployment/bootstrap-retail-rm-adb.sh"
embedding_model_line="$(grep -n 'RETAIL_EMBEDDING_MODEL_READY' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh" | head -n 1 | cut -d: -f1)"
evidence_package_line="$(grep -n '@"\${SCHEMA_DIR}/22_return_evidence_index.sql"' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh" | head -n 1 | cut -d: -f1)"
[[ -n "${embedding_model_line}" && -n "${evidence_package_line}" ]] ||
  fail "Retail embedding-model and return-evidence sequencing markers are missing."
if (( embedding_model_line >= evidence_package_line )); then
  fail "Retail must load ALL_MINILM_L12_V2 before compiling the return-evidence package."
fi
if grep -Eq 'GRANT SELECT ON SYS\.(V_\\\$(PARAMETER|OPTION|INMEMORY_AREA)|DBA_CONTEXT)' \
  "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh"; then
  fail "Retail bootstrap requests an unsupported or unnecessary ADB catalog grant."
fi
require_pattern 'rm -f "\$\{API_PRIVATE_KEY_FILE\}" "\$\{API_PUBLIC_KEY_FILE\}"' "scripts/bootstrap_app_vm.sh"
require_pattern 'NATIVE_SELECT_AI_ENABLED=true' "scripts/bootstrap_app_vm.sh"
require_pattern 'RETAIL_SELECTAI_V1' "main.tf"
require_pattern 'RETAIL_COMMERCE_TEAM' "main.tf"
require_pattern 'RETAIL_SIGNAL_TEAM,RETAIL_FULFILLMENT_TEAM,RETAIL_COMMERCE_TEAM,RETAIL_RETURNS_TEAM' "main.tf"
require_application_pattern 'RETAIL_SIGNAL_TEAM' "deployment/retail-native-ai-bootstrap.sql"
require_application_pattern 'RETAIL_FULFILLMENT_TEAM' "deployment/retail-native-ai-bootstrap.sql"
require_application_pattern 'RETAIL_COMMERCE_TEAM' "deployment/retail-native-ai-bootstrap.sql"
require_application_pattern 'RETAIL_RETURNS_TEAM' "deployment/retail-native-ai-bootstrap.sql"
# The Resource Manager demo endpoint is intentionally HTTP-only.  Do not let
# Helmet emit a CSP that would upgrade that public-IP URL to unsupported HTTPS.
require_application_pattern 'contentSecurityPolicy:[[:space:]]*false' "backend/server.js"
require_pattern 'set_bootstrap_phase "application_frontend_check"' "scripts/bootstrap_app_vm.sh"
# The governed Native Select AI adapter must use Retail's actor-aware connection
# helper.  Keep this explicit: a missing/renamed helper otherwise turns every
# AI-card request into a generic 503 before it reaches Autonomous Database.
require_application_pattern 'async function withUserConnection' "backend/config/database.js"
require_application_pattern 'withUserConnection,' "backend/config/database.js"
require_application_pattern 'return db[.]withUserConnection[(]resolveActor[(]actor[)][,] async' "backend/lib/nativeRetailAi.js"
require_application_pattern "RETAIL_PRODUCT_COMMERCE_V" "backend/lib/nativeRetailAi.js"
require_application_pattern 'GROUNDED_RESPONSE_RULES' "backend/lib/nativeRetailAi.js"
require_application_pattern 'RETAIL_DEMAND_FORECAST_SUMMARY_V' "backend/lib/nativeRetailAi.js"
require_application_pattern 'RETAIL_CREATOR_SIGNAL_MOMENTUM_V' "backend/lib/nativeRetailAi.js"
require_application_pattern 'APP_AUDIT_TRAIL' "backend/routes/returns.js"
require_application_pattern 'applicationAuditProof' "backend/lib/importWorkflowService.js"
require_application_pattern '@@refresh_social_signal_scores[.]sql' "db/data/load_oml_models.sql"
require_application_pattern 'SET virality_score[[:space:]]*=[[:space:]]*ROUND[(]' "db/data/refresh_social_signal_scores.sql"
require_application_pattern 'APP_INMEMORY_GENERATION_EVIDENCE' "db/schema/17_retail_dataset_lifecycle.sql"
require_application_pattern 'RETAIL_INMEMORY_CANONICAL_MIGRATION' "db/schema/20_retail_inmemory_evidence.sql"
if grep -Eq 'withActorConnection' "${APPLICATION_ROOT}/backend/lib/nativeRetailAi.js"; then
  fail "Native Select AI adapter must use the exported withUserConnection helper."
fi
require_pattern 'ignore_changes[[:space:]]*=[[:space:]]*\[key\]' "select-ai-key.tf"
require_pattern 'replace_triggered_by[[:space:]]*=[[:space:]]*\[oci_core_instance[.]application[.]id\]' "select-ai-key.tf"
require_pattern 'sha256[(]var[.]model_object_uri[)]' "main.tf"
require_pattern 'retail-livestack-resource-manager[.]zip' "README.md"
require_pattern 'include-agent-chat' "README.md"
require_pattern 'retail-ai-card-regression[.]mjs' "README.md"
require_pattern 'RETAIL_AI_CARD_REGRESSION_OK' "verification/retail-ai-card-regression.mjs"

if grep -Eqi '(native|supervisor)[[:space:]]+RUN_TEAM[[:space:]]+probes' \
  "${SOURCE_ROOT}/README.md"; then
  fail "README must not claim that bounded Apply acceptance executes RUN_TEAM."
fi

# The ADB driver is assembled with SQL heredocs.  Shell-style comments inside
# one would reach SQLcl as an invalid command, so reject them before packaging.
if ! awk '
  /<<SQL/ { in_sql = 1; next }
  in_sql && /^SQL$/ { in_sql = 0; next }
  in_sql && /^[[:space:]]*#/ { print FNR ":" $0; bad = 1 }
  END { exit bad }
' "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh"; then
  fail "Retail bootstrap SQL heredoc contains a shell-style comment."
fi

if grep -Eq 'resource[[:space:]]+"oci_identity_api_key"' "${SOURCE_ROOT}"/*.tf; then
  fail "The legacy IAM /20160918 API-key resource must not be shipped."
fi

if grep -Eq 'selectai_api_key_description[[:space:]]*=.*random_id' \
  "${SOURCE_ROOT}/select-ai-key.tf"; then
  fail "The API-key capacity guard must remain fully known during a fresh Plan."
fi

if grep -ERq '^[[:space:]]*(data|resource)[[:space:]]+"archive_file"' \
  "${SOURCE_ROOT}"/*.tf; then
  fail "Terraform must consume the prebuilt payload, not create an archive during a job."
fi

if grep -Eq 'hashicorp/archive' "${SOURCE_ROOT}/versions.tf"; then
  fail "The unused archive provider must not be shipped."
fi

if grep -Eq 'base64encode[[:space:]]*[(][[:space:]]*templatefile[[:space:]]*[(]' \
  "${SOURCE_ROOT}/compute-app.tf"; then
  fail "Cloud-init must be gzip-compressed before Base64 encoding."
fi

par_rotation_count="$(
  grep -Ec 'replace_triggered_by[[:space:]]*=[[:space:]]*\[terraform_data[.]bootstrap_configuration\]' \
    "${SOURCE_ROOT}/object-storage.tf"
)"
[[ "${par_rotation_count}" -eq 8 ]] ||
  fail "Every one of the eight expiring bootstrap PARs must rotate with the bootstrap generation."

if grep -Eq '^[[:space:]]*create_before_destroy[[:space:]]*=' "${SOURCE_ROOT}/select-ai-key.tf"; then
  fail "API-key replacement must free the old key slot before uploading the new public key."
fi

bash -n \
  "${SOURCE_ROOT}/scripts/bootstrap_app_vm.sh" \
  "${SOURCE_ROOT}/scripts/publish_selectai_api_key_activation.sh" \
  "${SOURCE_ROOT}/scripts/wait_for_selectai_api_key_callback.sh" \
  "${SOURCE_ROOT}/scripts/wait_for_bootstrap_callback.sh" \
  "${APPLICATION_ROOT}/deployment/bootstrap-retail-rm-adb.sh"

python3 -c \
  'import ast, pathlib, sys; ast.parse(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))' \
  "${SOURCE_ROOT}/scripts/wait_for_selectai_api_key_callback.py"

python3 "${SOURCE_ROOT}/verification/check-resource-manager-package.py" \
  --source-root "${SOURCE_ROOT}"
python3 "${SOURCE_ROOT}/verification/check-compute-metadata-budget.py"

if command -v terraform >/dev/null 2>&1; then
  terraform -chdir="${SOURCE_ROOT}" fmt -check -recursive >/dev/null
fi

printf 'PASS: Select AI Terraform and bootstrap security contract is intact.\n'
