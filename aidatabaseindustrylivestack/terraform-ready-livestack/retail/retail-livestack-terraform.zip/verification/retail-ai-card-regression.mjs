#!/usr/bin/env node
/*
 * Operator-run quality regression for every published Retail AI card.
 *
 * This check invokes OCI Generative AI. Ask Data calls are read-only. Agent
 * Console calls are advisory/read-only and do not create proposals or mutate
 * retail records. Terraform and cloud-init never run this script.
 *
 * Usage:
 *   node verification/retail-ai-card-regression.mjs \
 *     --base-url http://PUBLIC_IP:8505
 */

import assert from 'node:assert/strict';
import process from 'node:process';

const PROFILE = 'RETAIL_SELECTAI_V1';
const DEMO_USER = 'admin_jess';

const ASK_DATA_CARDS = [
  {
    question: 'Which products have the highest risk return value?',
    primaryKey: 'PRODUCT_NAME',
    metricKey: 'HIGH_RISK_RETURN_VALUE',
  },
  {
    question: 'Which fulfillment centers have low capacity?',
    primaryKey: 'CENTER_NAME',
    metricKey: 'QUANTITY_ON_HAND',
  },
  {
    question: 'Which fulfillment centers have inventory risk for AllTerrain Hiking Boots?',
    primaryKey: 'CENTER_NAME',
    sqlPattern: /UPPER\(product_name\)[\s\S]*AllTerrain Hiking Boots[\s\S]*inventory_risk\s*=\s*'AT_RISK'/i,
    validateRows(rows) {
      assert.ok(rows.every((row) => String(row.PRODUCT_NAME || '').toLowerCase() === 'allterrain hiking boots'),
        'AllTerrain fulfillment-risk card returned another product');
      assert.ok(rows.every((row) => String(row.INVENTORY_RISK || '') === 'AT_RISK'),
        'AllTerrain fulfillment-risk card returned a non-risk inventory row');
    },
  },
  {
    question: 'Which products are seeing the highest demand right now?',
    primaryKey: 'PRODUCT_NAME',
    metricKey: 'SEVEN_DAY_PREDICTED_DEMAND',
  },
  {
    question: 'Which creators are producing the fastest-rising signals?',
    primaryKey: 'CREATOR_NAME',
    metricKey: 'RISING_SIGNAL_POST_COUNT',
    validateRows(rows) {
      assert.ok(rows.length > 0, 'creator-momentum card returned no rows');
      assert.ok(rows.every((row) => String(row.CREATOR_NAME || '').trim()),
        'creator momentum returned a null creator name');
      assert.ok(rows.every((row) => String(row.CREATOR_HANDLE || '').trim()),
        'creator momentum returned a null creator handle');
    },
  },
  {
    question: 'What are the top products by revenue?',
    primaryKey: 'PRODUCT_NAME',
    metricKey: 'PRODUCT_REVENUE',
  },
  {
    question: 'Which return channels have the largest high-risk return value?',
    primaryKey: 'RETURN_CHANNEL',
    metricKey: 'HIGH_RISK_RETURN_VALUE',
  },
];

const AGENT_CONSOLE_CARDS = [
  {
    routedTeam: 'DEMAND_SIGNAL_AGENT',
    question: 'Which products are trending from viral social signals?',
  },
  {
    routedTeam: 'FULFILLMENT_OPTIMIZATION_AGENT',
    question: 'Which inventory risk needs attention?',
  },
  {
    routedTeam: 'COMMERCE_INTELLIGENCE_AGENT',
    question: 'Which product sales revenue needs attention?',
  },
  {
    routedTeam: 'RETURNS_TRIAGE_AGENT',
    question: 'Which return evidence needs review for a damaged return case?',
  },
];

function argument(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  return index === -1 ? fallback : process.argv[index + 1] || fallback;
}

const rawBaseUrl = argument('--base-url');
if (!rawBaseUrl) {
  console.error('Usage: node verification/retail-ai-card-regression.mjs --base-url http://PUBLIC_IP:8505 [--timeout-ms 360000]');
  process.exit(2);
}

const baseUrl = rawBaseUrl.replace(/\/+$/, '');
const timeoutMs = Number(argument('--timeout-ms', '360000'));
const results = [];

function normalize(value) {
  return String(value ?? '')
    .normalize('NFKD')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function compactNumberText(value) {
  return String(value ?? '').replace(/[^0-9.-]+/g, '');
}

function assertUsableProse(answer, rowCount, label) {
  const text = String(answer || '').trim();
  assert.ok(text.length >= 40, `${label} returned an empty or unusably short answer`);
  assert.doesNotMatch(text, /ADB native AI could not|unexpected response|unable to complete/i,
    `${label} returned a generic AI failure`);
  assert.doesNotMatch(text, /```|\bSQL\s+(?:Query|Used|Statement)\b|\bQuery\s*:/i,
    `${label} exposed SQL/query prose that belongs in the separate SQL panel`);
  if (rowCount > 0) {
    assert.doesNotMatch(text, /no (?:matching |specific )?evidence|insufficient (?:evidence|information)/i,
      `${label} ignored available governed evidence`);
  }
}

function assertReadOnlySql(sql, label) {
  const text = String(sql || '').trim();
  assert.match(text, /^(?:SELECT|WITH)\b/i, `${label} did not return a SELECT/WITH query`);
  assert.doesNotMatch(text, /\b(?:INSERT|UPDATE|DELETE|MERGE|DROP|ALTER|CREATE|GRANT|REVOKE|TRUNCATE|BEGIN|DECLARE|CALL|EXECUTE)\b/i,
    `${label} returned non-read-only SQL`);
}

function assertMetricMention(answer, value, label) {
  if (value === null || value === undefined || value === '') return;
  const compactAnswer = compactNumberText(answer);
  const compactValue = compactNumberText(value);
  assert.ok(compactValue && compactAnswer.includes(compactValue),
    `${label} did not cite the first-row metric ${value}`);
}

function assertFirstRowIsAuthoritative(answer, rows, key, label) {
  if (!key || !rows.length) return;
  const primary = normalize(rows[0]?.[key]);
  assert.ok(primary, `${label} first row has no ${key}`);
  const normalizedAnswer = normalize(answer);
  const primaryIndex = normalizedAnswer.indexOf(primary);
  assert.ok(primaryIndex >= 0, `${label} did not cite first-row ${key}: ${rows[0]?.[key]}`);

  const alternatives = [...new Set(rows.slice(1).map((row) => normalize(row?.[key])))]
    .filter((candidate) => candidate && candidate !== primary);
  for (const alternative of alternatives) {
    const alternativeIndex = normalizedAnswer.indexOf(alternative);
    assert.ok(alternativeIndex < 0 || primaryIndex < alternativeIndex,
      `${label} discussed another ${key} before the authoritative first row`);
  }
}

function assertCardEvidence(card, payload, proseField, label) {
  assert.equal(payload.profile, PROFILE, `${label} used the wrong Select AI profile`);
  assert.equal(payload.readOnly, true, `${label} did not preserve its read-only boundary`);
  assertReadOnlySql(payload.sql, label);
  if (card.sqlPattern) assert.match(payload.sql, card.sqlPattern, `${label} lost its reviewed SQL guard`);
  assert.ok(Array.isArray(payload.rows), `${label} did not return evidence rows`);
  assert.equal(payload.rowCount, payload.rows.length, `${label} rowCount does not match the returned rows`);
  assertUsableProse(payload[proseField], payload.rowCount, label);
  assertFirstRowIsAuthoritative(payload[proseField], payload.rows, card.primaryKey, label);
  if (card.metricKey && payload.rows.length) {
    assertMetricMention(payload[proseField], payload.rows[0]?.[card.metricKey], label);
  }
  if (card.countKey && payload.rows.length) {
    assertMetricMention(payload[proseField], payload.rows[0]?.[card.countKey], label);
  }
  card.validateRows?.(payload.rows);
}

async function post(path, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method: 'POST',
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
        'x-demo-user': DEMO_USER,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`HTTP ${response.status} returned non-JSON content: ${text.slice(0, 300)}`);
    }
    assert.equal(response.status, 200,
      `HTTP ${response.status}: ${JSON.stringify(payload).slice(0, 600)}`);
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

async function get(path) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      headers: { accept: 'application/json', 'x-demo-user': DEMO_USER },
      signal: controller.signal,
    });
    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`HTTP ${response.status} returned non-JSON content: ${text.slice(0, 300)}`);
    }
    assert.equal(response.status, 200,
      `HTTP ${response.status}: ${JSON.stringify(payload).slice(0, 600)}`);
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

async function run(label, callback) {
  const startedAt = Date.now();
  try {
    await callback();
    results.push({ label, status: 'PASS', elapsedMs: Date.now() - startedAt });
    console.log(`PASS  ${label}`);
  } catch (error) {
    results.push({ label, status: 'FAIL', elapsedMs: Date.now() - startedAt, error: error.message });
    console.error(`FAIL  ${label}: ${error.message}`);
  }
}

for (const [index, card] of ASK_DATA_CARDS.entries()) {
  await run(`Ask Data ${index + 1}/${ASK_DATA_CARDS.length}: ${card.question}`, async () => {
    const runSql = await post('/api/selectai/runsql', {
      question: card.question,
      profile: PROFILE,
    });
    const narrative = await post('/api/selectai/chat', {
      question: card.question,
      profile: PROFILE,
      showSql: true,
      history: [],
    });
    assert.equal(narrative.sql, runSql.sql, 'Narrate and Run SQL used different governed SQL');
    assert.deepEqual(narrative.referencedData?.columns, runSql.columns,
      'Narrate and Run SQL used different evidence columns');
    assert.equal(narrative.referencedData?.row_count, runSql.rowCount,
      'Narrate and Run SQL used different row counts');
    assertCardEvidence(card, { ...runSql, answer: narrative.answer }, 'answer', 'Ask Data card');
  });
}

for (const [index, card] of AGENT_CONSOLE_CARDS.entries()) {
  await run(`Agent Console ${index + 1}/${AGENT_CONSOLE_CARDS.length}: ${card.question}`, async () => {
    const payload = await post('/api/agents/chat', {
      question: card.question,
      profile: PROFILE,
    });
    assert.equal(payload.team, card.routedTeam, 'Agent Console selected the wrong governed specialist');
    assert.equal(payload.agentUsed, true, 'Agent Console did not use the configured native AI synthesis');
    assert.equal(payload.security?.readOnly, true, 'Agent Console did not preserve the read-only boundary');
    assert.equal(payload.security?.mutationPerformed, false, 'Agent Console performed an unexpected mutation');
    assert.ok(Array.isArray(payload.claims) && payload.claims.length > 0,
      'Agent Console returned no grounded claims');
    assert.ok(Array.isArray(payload.citations) && payload.citations.length > 0,
      'Agent Console returned no governed citations');
    assertUsableProse(payload.response, payload.citations.length, 'Agent Console card');
  });
}

await run('Retail Intelligence hybrid Returns card', async () => {
  const returns = await get('/api/returns/requests?limit=1');
  assert.ok(Array.isArray(returns) && returns.length > 0,
    'Returns Intelligence has no visible return fixture');
  const returnId = Number(returns[0]?.RETURN_ID || returns[0]?.return_id || 0);
  assert.ok(Number.isInteger(returnId) && returnId > 0,
    'Returns Intelligence fixture has no return identifier');
  const payload = await post('/api/returns/ask', {
    returnId,
    question: 'What evidence supports the recorded return recommendation?',
  });
  assert.equal(payload.oracle?.vectorUsed, true,
    'Retail Intelligence did not use the generation-bound Vector retrieval');
  assert.equal(payload.oracle?.indexName, 'IDX_RETURN_EVIDENCE_VEC',
    'Retail Intelligence did not report the exact hybrid Vector index');
  assert.equal(payload.oracle?.dimensions, 384,
    'Retail Intelligence did not use the approved embedding dimensions');
  assert.ok(Array.isArray(payload.citations) && payload.citations.length > 0,
    'Retail Intelligence returned no cited evidence');
  assertUsableProse(payload.answer, payload.citations.length, 'Retail Intelligence hybrid card');
});

const failed = results.filter((result) => result.status === 'FAIL');
console.log(`\nRetail AI-card summary: ${results.length - failed.length} passed, ${failed.length} failed.`);
if (failed.length) {
  console.log(JSON.stringify({ baseUrl, failed }, null, 2));
  process.exitCode = 1;
} else {
  console.log('RETAIL_AI_CARD_REGRESSION_OK');
}
