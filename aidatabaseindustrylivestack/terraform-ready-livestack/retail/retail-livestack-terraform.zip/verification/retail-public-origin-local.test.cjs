const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

// In the maintained tree this file belongs in source/verification. An override
// also permits running the same test unchanged from a temporary audit folder.
const root = process.env.RETAIL_SOURCE_ROOT || path.resolve(__dirname, '..');
const bootstrap = fs.readFileSync(path.join(root, 'scripts/bootstrap_app_vm.sh'), 'utf8');
const publisherPath = path.join(root, 'scripts/publish_selectai_api_key_activation.sh');
const publisher = fs.readFileSync(publisherPath, 'utf8');
const bash = process.env.RETAIL_TEST_BASH || 'bash';

function shellFunction(source, name) {
  const found = source.match(new RegExp('^' + name + '\\(\\) \\{[\\s\\S]*?^\\}', 'm'));
  assert.ok(found, `Actual shell function ${name} exists`);
  return found[0];
}

function shell(script, env = {}) {
  return spawnSync(bash, ['-c', script], {
    encoding: 'utf8',
    timeout: 5000,
    env: { ...process.env, ...env },
  });
}

const validatorSources = {
  publisher: shellFunction(publisher, 'valid_application_origin'),
  bootstrap: shellFunction(bootstrap, 'valid_application_origin'),
};
const accepted = [
  'http://130.61.44.195:8505',
  'http://129.146.81.104:8505',
  'http://1.0.0.1:8505',
  'http://223.255.255.255:8505',
];
const rejected = [
  '', 'http://localhost:8505', 'http://127.0.0.1:8505',
  'https://130.61.44.195:8505', 'HTTP://130.61.44.195:8505',
  'http://130.61.44.195', 'http://130.61.44.195:80',
  'http://130.61.44.195:85050', 'http://130.61.44.195:08505',
  'http://130.61.44.195:8505/', 'http://130.61.44.195:8505/path',
  'http://130.61.44.195:8505?q=1', 'http://130.61.44.195:8505#fragment',
  'http://user@130.61.44.195:8505', 'http://130.61.44.195:8505@evil.example',
  ' http://130.61.44.195:8505', 'http://130.61.44.195:8505 ',
  'http://130.61.44.195:8505\n', 'http://130.61.44.195:\n8505',
  'http://130.61.44.195:8505\r\nOTHER=value',
  'http://130.61.44.195:8505"', "http://130.61.44.195:8505'",
  'http://130.61.44.195:8505;touch /tmp/not-executed',
  'http://130.61.44:8505', 'http://130.61.44.195.1:8505',
  'http://256.61.44.195:8505', 'http://130.999.44.195:8505',
  'http://130.61.44.256:8505', 'http://130.061.44.195:8505',
  'http://013.61.44.195:8505', 'http://0.61.44.195:8505',
  'http://224.61.44.195:8505', 'http://255.255.255.255:8505',
  'http://[2001:db8::1]:8505', 'http://0x820b2cc3:8505',
];

test('Both actual shell origin validators remain identical', () => {
  assert.equal(validatorSources.publisher, validatorSources.bootstrap);
});

for (const [label, fn] of Object.entries(validatorSources)) {
  test(`${label}: canonical configured public origins accepted`, () => {
    for (const value of accepted) {
      const result = shell(`${fn}\nvalid_application_origin "$TEST_ORIGIN"`, {
        APPLICATION_PORT: '8505', TEST_ORIGIN: value,
      });
      assert.equal(result.status, 0, `${JSON.stringify(value)}: ${result.stderr}`);
    }
  });
  test(`${label}: malformed, foreign, loopback and injected origins rejected`, () => {
    for (const value of rejected) {
      const result = shell(`${fn}\nvalid_application_origin "$TEST_ORIGIN"`, {
        APPLICATION_PORT: '8505', TEST_ORIGIN: value,
      });
      assert.notEqual(result.status, 0, JSON.stringify(value));
    }
  });
  test(`${label}: configured port checked and bounded`, () => {
    for (const port of ['1', '65535']) {
      const result = shell(`${fn}\nvalid_application_origin "$TEST_ORIGIN"`, {
        APPLICATION_PORT: port, TEST_ORIGIN: `http://130.61.44.195:${port}`,
      });
      assert.equal(result.status, 0, `${port}: ${result.stderr}`);
    }
    for (const port of ['', '0', '65536', '08505', '-1', '8505x', '8505\n', '8505;true']) {
      const result = shell(`${fn}\nvalid_application_origin "$TEST_ORIGIN"`, {
        APPLICATION_PORT: port, TEST_ORIGIN: `http://130.61.44.195:${port}`,
      });
      assert.notEqual(result.status, 0, JSON.stringify(port));
    }
  });
}

const requireDatasetCommand = require(path.join(root, 'application/backend/middleware/requireDatasetCommand.js'));
function guard(origin, command = 'confirm-dataset-mutation') {
  const old = process.env.FRONTEND_URL;
  process.env.FRONTEND_URL = 'http://130.61.44.195:8505';
  let response = { next: false };
  const req = {
    headers: { ...(origin === undefined ? {} : { origin }), ...(command === undefined ? {} : { 'x-dataset-command': command }) },
    protocol: 'http', get: () => '130.61.44.195:8505',
  };
  const res = { status(status) { response.status = status; return this; }, json(body) { response.body = body; return this; } };
  try { requireDatasetCommand(req, res, () => { response.next = true; }); }
  finally { old === undefined ? delete process.env.FRONTEND_URL : process.env.FRONTEND_URL = old; }
  return response;
}

test('Actual Retail mutation middleware accepts its configured browser origin', () => {
  assert.equal(guard('http://130.61.44.195:8505').next, true);
});
test('Actual Retail mutation middleware rejects foreign, localhost, HTTPS and malformed origins', () => {
  for (const origin of ['http://evil.example', 'http://localhost:8505', 'https://130.61.44.195:8505', 'null', 'not a URL']) {
    const response = guard(origin);
    assert.equal(response.next, false);
    assert.equal(response.status, 403, origin);
    assert.equal(response.body.code, 'DATASET_ORIGIN_FORBIDDEN');
  }
});
test('Actual Retail mutation middleware still requires explicit mutation header', () => {
  const response = guard('http://130.61.44.195:8505', '');
  assert.equal(response.next, false);
  assert.equal(response.status, 428);
  assert.equal(response.body.code, 'DATASET_COMMAND_REQUIRED');
});
test('Existing non-browser no-Origin semantics remain unchanged with confirmation header', () => {
  assert.equal(guard(undefined).next, true);
});

const callbackEnv = {
  API_KEY_ACTIVATION_UPLOAD_URL: 'https://unit.invalid/activation',
  DEPLOYMENT_ID: '1234abcd',
  INSTANCE_OCID: 'ocid1.instance.oc1.test',
  API_KEY_FINGERPRINT: Array(16).fill('ab').join(':'),
  APPLICATION_ORIGIN: 'http://130.61.44.195:8505',
  APPLICATION_PORT: '8505',
  ACTIVATION_TTL_SECONDS: '3600',
  PUBLISHER: publisherPath,
};
const mockPublisher = `
date() {
  if [[ "$*" == '-u +%s' ]]; then printf '%s\\n' 1700000000;
  elif [[ "$*" == *'@1700000000'* ]]; then printf '%s\\n' '2023-11-14T22:13:20Z';
  elif [[ "$*" == *'@1700003600'* ]]; then printf '%s\\n' '2023-11-14T23:13:20Z';
  else printf 'Unexpected date arguments\\n' >&2; return 90; fi
}
curl() {
  local file=''
  while (( $# )); do
    if [[ "$1" == '--upload-file' ]]; then file="$2"; shift; fi
    shift
  done
  [[ -n "$file" && -s "$file" ]] || return 91
  printf 'CAPTURED_CALLBACK=%s\\n' "$(/bin/cat "$file")" >&2
}
source "$PUBLISHER"
`;

let published;
test('Actual publisher emits bound valid origin in mocked offline callback', () => {
  const result = shell(mockPublisher, callbackEnv);
  assert.equal(result.status, 0, result.stderr);
  const match = result.stderr.match(/CAPTURED_CALLBACK=(\{[\s\S]*\})/);
  assert.ok(match, result.stderr);
  published = JSON.parse(match[1]);
  assert.equal(published.application_origin, callbackEnv.APPLICATION_ORIGIN);
  assert.equal(published.deployment_id, callbackEnv.DEPLOYMENT_ID);
  assert.equal(published.instance_ocid, callbackEnv.INSTANCE_OCID);
  assert.equal(published.fingerprint, callbackEnv.API_KEY_FINGERPRINT);
  assert.equal(published.state, 'ACTIVE');
});
test('Actual publisher fails before upload for missing or invalid public origin', () => {
  for (const origin of ['', 'http://localhost:8505', 'https://130.61.44.195:8505', 'http://130.61.44.195:8505\nINJECTED=1']) {
    const result = shell(mockPublisher, { ...callbackEnv, APPLICATION_ORIGIN: origin });
    assert.notEqual(result.status, 0);
    assert.doesNotMatch(result.stderr, /CAPTURED_CALLBACK=/);
  }
});

const bashMajor = Number(shell('printf "%s" "${BASH_VERSINFO[0]}"').stdout);
test('Actual consumer accepts offline publisher callback and preserves public origin', {
  skip: bashMajor < 4 ? 'Native Bash3 cannot run existing Bash4 lowercase expansion; run with RETAIL_TEST_BASH=/path/to/bash4+' : false,
}, () => {
  assert.ok(published);
  const script = `
set -Eeuo pipefail
${validatorSources.bootstrap}
${shellFunction(bootstrap, 'wait_for_api_key_activation')}
date() {
 if [[ "$*" == '-u +%s' ]]; then printf '%s\\n' 1700000001;
 elif [[ "$*" == *'2023-11-14T22:13:20Z'* ]]; then printf '%s\\n' 1700000000;
 elif [[ "$*" == *'2023-11-14T23:13:20Z'* ]]; then printf '%s\\n' 1700003600;
 else return 90; fi
}
curl() { printf '%s' "$ACTIVATION_JSON"; }
sleep() { printf 'Unexpected retry\\n' >&2; exit 92; }
log() { :; }
fail() { printf '%s\\n' "$*" >&2; exit 93; }
FRONTEND_URL=''
wait_for_api_key_activation
printf 'FRONTEND_URL=%s\\n' "$FRONTEND_URL"
`;
  const result = shell(script, {
    ...callbackEnv, LOCAL_API_KEY_FINGERPRINT: callbackEnv.API_KEY_FINGERPRINT,
    ACTIVATION_JSON: JSON.stringify(published), API_KEY_ACTIVATION_URL: 'https://unit.invalid/activation',
  });
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /FRONTEND_URL=http:\/\/130\.61\.44\.195:8505/);
});
