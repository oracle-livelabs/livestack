/**
 * Oracle AI Database 26ai Connection Pool Manager
 * Handles connection pooling for Oracle AI Database 26ai Free
 */

const oracledb = require('oracledb');
const { AsyncLocalStorage } = require('node:async_hooks');

// Use Thick mode when wallet-based Oracle AI Database 26ai connections are configured
// Thin mode (default in 6.x) works for some configs
let poolPromise = null;
let poolResetPromise = null;
const DEMO_USER_PATTERN = /^[a-z][a-z0-9_]{0,99}$/;
const requestIdentity = new AsyncLocalStorage();

function buildPoolConfig() {
  const poolConfig = {
    user: process.env.ORACLE_USER || 'LIVESTACK',
    password: process.env.APP_SCHEMA_PASSWORD || 'livestackrulez!',
    connectString: process.env.ORACLE_CONNECTION_STRING,
    poolMin: parseInt(process.env.ORACLE_POOL_MIN) || 2,
    poolMax: parseInt(process.env.ORACLE_POOL_MAX) || 10,
    poolIncrement: parseInt(process.env.ORACLE_POOL_INCREMENT) || 1,
    poolTimeout: 60,
    queueMax: -1,
    queueTimeout: 60000,
    enableStatistics: true
  };

  if (process.env.ORACLE_WALLET_LOCATION) {
    poolConfig.walletLocation = process.env.ORACLE_WALLET_LOCATION;
    poolConfig.walletPassword = process.env.ORACLE_WALLET_PASSWORD;
    // Thin mode needs configDir to locate tnsnames.ora inside the wallet
    poolConfig.configDir = process.env.ORACLE_WALLET_LOCATION;
  }

  return poolConfig;
}

function isReconnectError(err) {
  const code = String(err?.code || '');
  const message = String(err?.message || '');

  return [
    'NJS-503',
    'DPI-1010',
    'DPI-1080',
    'ORA-03113',
    'ORA-03114',
    'ORA-12170',
    'ORA-12514',
    'ORA-12541',
    'ORA-12545',
  ].includes(code) || /EHOSTUNREACH|ECONNREFUSED|ENOTFOUND|connection to host .* could not be established/i.test(message);
}

async function createPool() {
  const poolConfig = buildPoolConfig();
  poolPromise = oracledb.createPool(poolConfig);
  try {
    const pool = await poolPromise;
    console.log(`Oracle connection pool created (min: ${pool.poolMin}, max: ${pool.poolMax})`);
    return pool;
  } catch (err) {
    poolPromise = null;
    throw err;
  }
}

async function resetPool(reason = 'connection reset') {
  if (poolResetPromise) {
    return poolResetPromise;
  }

  poolResetPromise = (async () => {
    const existingPoolPromise = poolPromise;
    poolPromise = null;

    if (existingPoolPromise) {
      try {
        const existingPool = await existingPoolPromise;
        await existingPool.close(10);
        console.warn(`Oracle connection pool reset (${reason})`);
      } catch (err) {
        console.warn('Error closing stale Oracle pool:', err.message || err);
      }
    }

    return createPool();
  })();

  try {
    return await poolResetPromise;
  } finally {
    poolResetPromise = null;
  }
}

async function initialize() {
  try {
    // If using wallet, initialize thick mode
    if (process.env.ORACLE_WALLET_LOCATION) {
      try {
        oracledb.initOracleClient({
          libDir: process.env.ORACLE_CLIENT_DIR || undefined,
          configDir: process.env.ORACLE_WALLET_LOCATION
        });
        console.log('Oracle Thick mode initialized with wallet');
      } catch (err) {
        // Thick mode may already be initialized
        if (!err.message.includes('already initialized')) {
          console.warn('Thick mode init warning:', err.message);
        }
      }
    }

    if (poolPromise) {
      return poolPromise;
    }

    const pool = await createPool();

    // Set default output format
    oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
    oracledb.autoCommit = true;
    oracledb.fetchAsString = [oracledb.CLOB];

    return pool;
  } catch (err) {
    console.error('Failed to create Oracle connection pool:', err);
    throw err;
  }
}

async function getConnection() {
  if (!poolPromise) {
    await initialize();
  }

  try {
    const pool = await poolPromise;
    const connection = await pool.getConnection();
    await connection.ping();
    await clearUserContext(connection);
    return connection;
  } catch (err) {
    if (isReconnectError(err)) {
      await resetPool(err.code || err.message || 'connection failure');
      const pool = await poolPromise;
      const connection = await pool.getConnection();
      await connection.ping();
      await clearUserContext(connection);
      return connection;
    }
    throw err;
  }
}

async function clearUserContext(connection) {
  await connection.execute('BEGIN hospitality_security_pkg.clear_user_context; END;');
}

function normalizeDemoUser(username) {
  const normalized = String(username || '').trim().toLowerCase();
  return DEMO_USER_PATTERN.test(normalized) ? normalized : null;
}

function runWithDemoUser(username, callback) {
  const normalized = normalizeDemoUser(username);
  if (!normalized) throw new Error('A validated demo user is required.');
  return requestIdentity.run({ demoUser: normalized }, callback);
}

async function setUserContext(connection, username) {
  const normalized = normalizeDemoUser(username);
  if (!normalized) {
    const error = new Error('Unknown or inactive demo user.');
    error.statusCode = 403;
    throw error;
  }

  try {
    await connection.execute(
      'BEGIN hospitality_security_pkg.set_user_context(:username); END;',
      { username: normalized }
    );
  } catch (error) {
    if (String(error?.message || '').includes('ORA-20001')) {
      error.statusCode = 403;
    }
    throw error;
  }
  return normalized;
}

async function withUserConnection(username, callback) {
  let connection;
  let clearError = null;
  try {
    connection = await getConnection();
    await setUserContext(connection, username);
    return await callback(connection);
  } finally {
    if (connection) {
      try {
        await clearUserContext(connection);
      } catch (error) {
        clearError = error;
        console.error('Failed to clear Hospitality VPD context:', error.message || error);
      }
      try {
        if (clearError) {
          await connection.close({ drop: true });
        } else {
          await connection.close();
        }
      } catch (_) { /* ignore */ }
    }
  }
}

async function validateDemoUser(username) {
  const normalized = normalizeDemoUser(username);
  if (!normalized) return null;
  const result = await execute(
    `SELECT username, full_name, role, region
       FROM app_users
      WHERE username = :username
        AND is_active = 1`,
    { username: normalized }
  );
  return result.rows[0] || null;
}

async function closePool() {
  if (poolPromise) {
    try {
      const pool = await poolPromise;
      await pool.close(10);
      console.log('Oracle connection pool closed');
    } catch (err) {
      console.error('Error closing pool:', err);
    } finally {
      poolPromise = null;
    }
  }
}

/**
 * Execute a query with automatic connection management
 */
async function execute(sql, binds = {}, options = {}) {
  const requestUser = requestIdentity.getStore()?.demoUser;
  if (requestUser) {
    return executeAsUser(sql, binds, requestUser, options);
  }

  let connection;
  try {
    connection = await getConnection();
    const result = await connection.execute(sql, binds, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      ...options
    });
    return result;
  } finally {
    if (connection) {
      try { await connection.close(); } catch (e) { /* ignore */ }
    }
  }
}

/**
 * Execute a query with VPD user context set on the same connection.
 * Calls hospitality_security_pkg.set_user_context(username) before running the query
 * so Oracle VPD policies filter rows based on the user's role/region.
 */
async function executeAsUser(sql, binds = {}, username = null, options = {}) {
  return withUserConnection(username, (connection) =>
    connection.execute(sql, binds, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      ...options
    })
  );
}

/**
 * Execute a PL/SQL block with VPD user context and consume a returned
 * SYS_REFCURSOR before closing the pooled connection.
 */
async function executeCursorAsUser(sql, binds = {}, cursorBindName = 'cursor', username = null, options = {}) {
  let resultSet;
  const { maxRows = 1000, ...executeOptions } = options;

  return withUserConnection(username, async (connection) => {
    try {
      const result = await connection.execute(sql, binds, {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
        ...executeOptions
      });

      resultSet = result.outBinds?.[cursorBindName];
      if (!resultSet || typeof resultSet.getRows !== 'function') {
        throw new Error(`PL/SQL block did not return cursor bind "${cursorBindName}"`);
      }

      const rows = await resultSet.getRows(maxRows);
      return { ...result, rows };
    } finally {
      if (resultSet) {
        try { await resultSet.close(); } catch (e) { /* ignore */ }
      }
    }
  });
}

/**
 * Execute a PL/SQL procedure
 */
async function callProcedure(sql, binds = {}) {
  let connection;
  try {
    connection = await getConnection();
    const result = await connection.execute(sql, binds);
    return result;
  } finally {
    if (connection) {
      try { await connection.close(); } catch (e) { /* ignore */ }
    }
  }
}

module.exports = {
  initialize,
  getConnection,
  closePool,
  execute,
  executeAsUser,
  executeCursorAsUser,
  withUserConnection,
  setUserContext,
  clearUserContext,
  validateDemoUser,
  runWithDemoUser,
  callProcedure,
  oracledb
};
